#include<conio.h>
#include<stdio.h>

int main(void) {
    char name[20];
    unsigned int age=0;
    unsigned char yn=' ';
    clrscr();;
    printf("What is your name? ");
    scanf("%19s", name);
    printf("\nHello, %s. How old are you? ", name);
    scanf("%d", &age);
    printf("\nDo you like being %d (Y/N)?\n", age);
    yn=cgetc();
    printf("\nYou entered ");
    cputc(yn);
    printf("\n");
    if (yn=='y' || yn=='Y') 
        printf("\nThat's good to hear.\n");
    else
        printf("\nI'm sorry to hear that.\n");
    cputs("\nOK, bye.");
    return 0;
}

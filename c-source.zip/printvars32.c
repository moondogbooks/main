#include<stdio.h>

int main(void) {
    signed long var1 = 0;    //Signed 32-bit value 
    unsigned long var2 = 0;  //Unsigned 32-bit value
    long var3 = 0;           //Signed 32-bit value (default for long is signed)

    //This time var2 starts at 10000000 and will increase by 10000000 for each iteration.
    //When it overflows and becomes less than 10000000, the loop will end.
    for (var2=10000000; var2>=10000000; var2+=10000000) { 
        var1+=10000000; //Increment var1 by 10000000.
        var3+=10000000; //Increment var3 by 10000000.
        //Notice that var3 is a signed long, but it is printed as unsigned.
        printf("var1 = %ld, var2 = %lu,  var3 = %lu\n", var1, var2, var3);
    }    

    return 0;
}

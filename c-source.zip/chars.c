#include<stdio.h>

int main(void) {
    unsigned char letter = 'a'; 
    printf("%c=%d\n", letter,letter);
    letter++;
    printf("%c=%d\n", letter,letter);
    return 0;
}

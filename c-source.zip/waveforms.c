#include <stdio.h>
#include <conio.h>
#include "cinc64.h"

void init(void);
void play_waveforms(void);
void finalize(void);

int main(void) {
    init();
    play_waveforms();
    finalize();
    return 0;
}

void init(void) {
    unsigned char* s_index=0; //sid pointer index
    //Initialize SID
    for (s_index=&SID_START; s_index<=&SID_END; s_index++) {
        *s_index=0;
    }    
    clrscr();

    SID_VOLUME=15;
    //Set ASDR
    VOICE_1_AD=68;
    VOICE_1_SR=68;
    //Set Pitch
    VOICE_1_LOW_FREQ=75;
    VOICE_1_HIGH_FREQ=34;
    //Set pulse width for the pulse waveform.
    VOICE_1_PULSE_LOW=64;
    VOICE_1_PULSE_HIGH=1;
}

void play_waveforms(void) {
    VOICE_1_WAVEFORM=17; //Start triangle waveform.
    printf("The triangle waveform is playing.\n\n");
    WAIT(180);
    VOICE_1_WAVEFORM=16; //End triangle waveform.
    WAIT(60);
    VOICE_1_WAVEFORM=33; //Start sawtooth waveform.
    printf("The sawtooth waveform is playing.\n\n");
    WAIT(180);
    VOICE_1_WAVEFORM=32; //End sawtooth waveform.
    WAIT(60);
    VOICE_1_WAVEFORM=65; //Start pulse waveform.
    printf("The pulse waveform is playing.\n\n");
    WAIT(180);
    VOICE_1_WAVEFORM=64; //End pulse waveform.
    WAIT(60);
    VOICE_1_WAVEFORM=129; //Start noise waveform.
    printf("The noise waveform is playing.\n\n");
    WAIT(180);
    VOICE_1_WAVEFORM=128; //End noise waveform.
}

void finalize(void) {
    unsigned char* s_index=0; //sid pointer index
    //Initialize SID
    for (s_index=&SID_START; s_index<=&SID_END; s_index++) {
        *s_index=0;
    }     
}

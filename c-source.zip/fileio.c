#include <stdio.h>
#include <conio.h>

int main(void) {
    FILE *fp;

    //Not really necessary as 's' (sequential) 
    //is the default file type.
    _filetype = 's'; 

    fp = fopen("hello.txt", "w"); //w=write

    if (fp != NULL) {
        fprintf(fp, "Hello, World\n");
        fclose(fp);
    } else {
        printf("Could not write to 'hello.txt'.\n");
        return 0;
    }

    fp = fopen("hello.txt", "a"); //a=apend
    if (fp != NULL) {
        fprintf(fp, "How now brown chow?\n");
        fclose(fp);        
    } else {
        printf("Could not append 'hello.txt'.\n");
    }

    printf("\nPress any key to see the file contents.\n");
    while (cgetc()==0) { }

    fp = fopen("hello.txt", "r"); //r=read

    if (fp != NULL) {
        char line[80];
        while (fgets(line, sizeof(line), fp)) {
            printf("%s", line);
        }
        fclose(fp);
    } else {
        printf("Could not read 'hello.txt'.\n");
    }

    return 0;
}

#include "cinc64.h"

const unsigned char airplane[] = {
    224,0,0, 240,0,0, 248,0,0,
    252,0,0, 254,0,0, 255,255,128,
    255,255,192, 255,255,224, 249,36,16,
    249,36,8, 255,255,255, 255,255,255,
    255,255,255, 255,255,254, 127,255,252,
    63,255,248, 63,240,0, 63,224,0,
    63,192,0, 63,128,0, 63,0,0
};

const unsigned char chopper[] = {
    0,0,0, 127,255,254, 0,16,0,
    0,56,0, 0,56,0, 0,124,0,
    0,214,0, 1,147,0, 1,147,0,
    1,147,0, 1,255,0, 1,187,0,
    0,254,0, 0,124,0, 0,68,0,
    0,198,0, 0,130,0, 1,199,0,
    0,0,0, 0,0,0, 0,0,0
};

unsigned int sprite_starting_address;


void load_aircraft_shape_data(unsigned int starting_address) {
	unsigned char index=0;
	//Load airplane shape.
    for (index=0; index<=62;index++) {
        POKE(index+starting_address, airplane[index]);
    }
    
    //Load chopper shape.
    for (index=0; index<=62;index++) {
        POKE(index+starting_address+64, chopper[index]);
    }    
    sprite_starting_address = starting_address;
}

void make_airplane(unsigned char sprite_number,
	unsigned char expand_x, unsigned char expand_y) {
	POKE(2040+sprite_number, sprite_starting_address/64);
	SPRITE_EXPAND_X |= (1 << expand_x);
	SPRITE_EXPAND_Y |= (1 << expand_y);
}

void make_chopper(unsigned char sprite_number,
	unsigned char expand_x, unsigned char expand_y) {
	POKE(2040+sprite_number, (sprite_starting_address/64)+1);
	SPRITE_EXPAND_X |= (1 << expand_x);
	SPRITE_EXPAND_Y |= (1 << expand_y);
}

void initialize_sprites() {
	unsigned char index=0;
	//Initialize sprite coordinates.
    for (index=SPRITE_0_X;index<=SPRITE_X_OVERFLOW;index++) {
        *(unsigned char*)index = 0;
    }
    SPRITE_EXPAND_X=0;
    SPRITE_EXPAND_Y=0;
}

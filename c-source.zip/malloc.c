#include <stdio.h>
#include <stdlib.h>
#include <conio.h>

unsigned char *ar1;
unsigned int index=0;

void print_max_allocation(void) {    
    printf("Largest malloc available: %u\n", _heapmaxavail());
}


int main(void) {
    printf("Program start\n");
    print_max_allocation();
    ar1 = malloc(5000);

    if (ar1 == NULL) {
        printf("malloc failed\n");
        return 0;
    }

    //No need to set the seed for this test.
    for (index=0; index<=4999; index++) {
        ar1[index] = rand()%256;
    }

	printf("\n5k Array created and filled.\n");

    print_max_allocation();

    printf("Array freed.\n");
    free(ar1);
    print_max_allocation();    

    return 0;
}



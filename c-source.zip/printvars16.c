#include<stdio.h>

int main(void) {
    signed int var1 = 0;    //Signed 16-bit value 
    unsigned int var2 = 0;  //Unsigned 16-bit value
    int var3 = 0;           //Signed 16-bit-value 

    //This time var2 starts at 1000 and will increase by 1000 for each iteration.
    //When it oveflows and become less than 1000 the loop will end.
    for (var2=1000; var2>=1000; var2+=1000) { 
        var1+=1000; //Increment var1 by 1000.
        var3+=1000; //Increment var3 by 1000.
        printf("var1 = %d, var2 = %u,  var3 = %d\n", var1, var2, var3);
    }    

    return 0;
}

#include<stdio.h>

/*
 * times2 and say_something do not need prototypes.
 * They are implemented(typed in) before the are called.
 */
int times2(int myvar) {
	return myvar*=2;
}

void say_something(void) {
	printf("Hi there.\n");
}

//The implentation is entered after the function is called.
//That is why we need the protoype.
int times3(int myvar); 

//The prototype for printf is in stdio.h.

int main(void) {
	int var1=24;
	//Notice that you can call a function within a function.
	printf("%d times 2 is %d\n", var1, times2(var1));
	say_something();
	printf("%d times 3 is %d\n", var1, times3(var1));
	printf("The value of var1 does not change. It is still %d.\n", var1);
    return 0;
}

int times3(int myvar) {
	return myvar*=3;
}

.export _installtsr
.export _deinstalltsr

.macro poke addr, value
    lda #value
    sta addr
.endmacro

_installtsr:
    sei
    jsr initsound

    lda #<playtune
    sta $0314
    lda #>playtune
    sta $0315

    cli
    rts

_deinstalltsr:
    sei
    jsr initsound ; Silence on exit
    lda #$31
    sta $0314
    lda #$ea
    sta $0315
    cli
    rts

initsound:
    ;Initialize SID registers
    ldx #25
    lda #0
@loop: ;The @ makes the label local. 
       ;Loop is such a generic name for a label.
    sta $d3ff,x
    dex
    bne @loop

    poke $d418, 15       ; Volume
    poke $d413, 155      ; Voice 3 attack/decay
    poke $d414, 9        ; Voice 3 sustain/release
    poke tuneti, 0
    poke tuneidx, 0
    poke noteon, 0
    rts

;We will run this 60 times a second. 
;It is attached to the timed interrupt at $EA31.
playtune:
    ldx tuneidx

    lda noteon
    beq startnote

    ; A note is currently playing.
    lda tuneti
    cmp tune+2,x
    bcc plyexit          ; Timer is below duration.
    beq plyexit          ; Timer equals duration.

    ; Stop the note.
    poke $d412, 32       ; Gate off, triangle selected
    poke noteon, 0
    poke tuneti, 0

    ; Advance to next three-byte tune entry.
    inc tuneidx
    inc tuneidx
    inc tuneidx

    lda tuneidx
    cmp #15              ; Five entries × three bytes
    bcc irqexit

    poke tuneidx, 0
    jmp irqexit


startnote:
    poke noteon, 1
    poke tuneti, 0

    ; Reload X because the macro calls above alter A only, not X.
    ldx tuneidx

    ; Voice 3 frequency.
    lda tune,x
    sta $d40f            ; Frequency high byte

    lda tune+1,x
    sta $d40e            ; Frequency low byte

    poke $d412, 33       ; Gate on, triangle waveform


plyexit:
    inc tuneti

irqexit:
    jmp $ea31


; Each entry: frequency high, frequency low, duration
tune:
    .byte 8,97,30
    .byte 11,48,30
    .byte 8,97,30
    .byte 6,71,30
    .byte 4,48,60

noteon:
    .byte 0

tuneti:
    .byte 0

tuneidx:
    .byte 0

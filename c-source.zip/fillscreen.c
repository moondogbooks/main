#include <conio.h>
#include "h/mydefs.h";

int main(void) {
    // Cycle c from 0 to 255.
    unsigned char c=0;

    do {
        fillchar(c);
        c++; //wink, wink, nudge, nudge
    } while (c > 0);  
    clrscr();
    return 0;
}





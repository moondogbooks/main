#include <c64.h>
#include <conio.h>
#define KEY_COUNT *(unsigned char*)0x00C6

unsigned char save_backcolor=0;
unsigned char save_bordercolor=0;

const unsigned char spritedata[] = {
    224,0,0,
    240,0,0,
    248,0,0,
    252,0,0,
    254,0,0,
    255,255,128,
    255,255,192,
    255,255,224,
    249,36,16,
    249,36,8,
    255,255,255,
    255,255,255,
    255,255,255,
    255,255,254,
    127,255,252,
    63,255,248,
    63,240,0,
    63,224,0,
    63,192,0,
    63,128,0,
    63,0,0
};

void init(void);
void animate(void);
void finalize(void);
void raster_wait(void);

int main(void) {
    init();
    animate();
    finalize();
    return 1;
}

void init(void) {
    unsigned int index=0;
    clrscr();
    save_backcolor=bgcolor(COLOR_BLACK);
    save_bordercolor=bordercolor(COLOR_WHITE);
    //Initialize sprite coordinates.
    for (index=0xD000;index<=0xD010;index++) {
        *(unsigned char*)index = 0;
    }
    //Expand sprite's 0 and 1 horizontally and vertically.
    *(unsigned char *)0xD017=3;
    *(unsigned char *)0xD01D=3;
    //Copy spritedata to sprite shape memory.
    for (index=0; index<=62;index++) {
        *(unsigned char*)(index+832)=spritedata[index];
    }
    //Set sprite data location to 832(13*64) for all 3 sprites.
    *(unsigned char *) 2040=13;
    *(unsigned char *) 2041=13;
    *(unsigned char *) 2042=13;

    //Turn on sprites 0, 1 and 2.
    *(unsigned char*)0xD015=7;
    //Set sprite 2 Y position to 100.
    *(unsigned char*)0xD005=100;
}

void animate() {
    unsigned int index=0;
    while(KEY_COUNT == 0) {

        for (index=0; index <=255; index++) {
            *(unsigned char*)0xD000=index;
            *(unsigned char*)0xD001=index;
            *(unsigned char*)0xD002=index;
            *(unsigned char*)0xD003=255-index;
            *(unsigned char*)0xD004=index;
            if (KEY_COUNT > 0) break; //Exit on keypress
            raster_wait();
        }

        //Let sprite 2 make it across the screen.
        //Turn on sprite x overflow for sprite 2.
        *(unsigned char *)0xD010 = 4;    
        for (index=0; index <=88; index++) {
            *(unsigned char*)0xD004=index;
            if (KEY_COUNT > 0) break; //Exit on keypress
            //Raster delay
            raster_wait();
        }
        *(unsigned char *)0xD010 = 0; //Turn off sprite x overflow.    

    }
}

void finalize() {
    *(unsigned char*)0xD015=0; //Hide all sprites.
    bgcolor(save_backcolor);
    bordercolor(save_bordercolor);
    KEY_COUNT=0;
}

void raster_wait(void) {
     while (*(unsigned char*)0xD011>=128) {}
     while (*(unsigned char*)0xD011<128) {}
}

#include<stdio.h>

int main(void) {
    unsigned char x=10;
    
    do {
		printf("do while %d\n",x);
        x++;
	} while (x < 10);
	
    while(x < 10) {
		printf("while %d\n",x);
        x++;
	} while (x < 10);
    
    return 0;
}

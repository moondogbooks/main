#include<stdio.h>

int main(void) {
    unsigned char x=10;
    
    /*
     * Test is applied at the beginning of the loop.
     * Test fails and loop is never executed.
     */  
    while(x < 10) {
		printf("while %d\n",x);
        x++;
	} while (x < 10);
    
    /*
     * Test is applied at the end of the loop.
     * Test fails, but since it is applied at the end,
     * the loop does run once.
     */     
    do {
		printf("do while %d\n",x);
        x++;
	} while (x < 10);
	  
    return 0;
}

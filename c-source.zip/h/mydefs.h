#define SCREEN_START (unsigned char*)0x0400

void fillchar(unsigned charcode);

#include <stdio.h>
#include <c64.h>
#include <conio.h>
#include <stdlib.h>
#include "cinc64.h"
#include "aircraft_factory.h"

unsigned int save_background_color=0;
unsigned int save_bordercolor=0;
unsigned int starat[20]; //20 Random Stars

void init(void);
void animate(void);
void finalize(void);
void set_star_colors(void);
void plot_stars(void);
void remove_stars(void);

int main(void) {
    init();
    animate();
    finalize();
    return 0;
}

void init(void) {
    unsigned int index=0;
    unsigned char* ptr_index;
    unsigned int spritey=60;
    unsigned long ti; //internal clock
    ti  = LOW_CLOCK;
    ti |= (unsigned long)MID_CLOCK << 8;
    ti |= (unsigned long)HIGH_CLOCK << 16;
    srand(ti); //Seed random number generator using the 24-bit internal
               //clock at $A0-$A2.
                 
    save_background_color=bgcolor(COLOR_BLACK);
    save_bordercolor=bordercolor(COLOR_WHITE);
    clrscr();
    
    load_aircraft_shape_data(832);
    initialize_sprites();
    make_airplane(0, 1, 1);
    make_airplane(1, 1, 1);
    for(index=2;index<=5;index++) make_airplane(index, 0, 0);
    make_chopper(6,0,0);
    make_chopper(7,0,0);   
    
    //Set sprite Y positions for sprites 2-5.
    for (ptr_index=&SPRITE_2_Y; ptr_index<=&SPRITE_5_Y; ptr_index+=2) {
      spritey+=30; 
      POKE(ptr_index, spritey);
    }
    //Set sprite X position for sprites 6 and 7.
    SPRITE_6_X = 80;
    SPRITE_7_X = 240;
    printf("Press any key to exit.");
    set_star_colors();
}

void animate(void) {
    unsigned int index=0;
    unsigned char text_color=0;
    //Let's use the KEY_COUNT register this time to signal that it
    //is time to exit.
    while(KEY_COUNT == 0) {
        ++BORDER_COLOR;
        plot_stars(); //Plot 20 random stars.
        text_color=rand()%15+1;
        for (index=0xD800;index<=0xD815;index++)
			POKE(index, text_color); 
        //Turn on sprites 0 - 7.
        SPRITE_ENABLE=255;
        for (index=0; index <=255; index++) {
            SPRITE_0_X=index;
            SPRITE_0_Y=index;
            SPRITE_1_X=index;
            SPRITE_1_Y=255-index;
            SPRITE_2_X=index;
            SPRITE_3_X=index;
            SPRITE_4_X=index;
            SPRITE_5_X=index;
            SPRITE_6_Y=index;
            SPRITE_7_Y=255-index;
            if (KEY_COUNT > 0) break; //Exit on keypress
            RASTER();
        }

        //Let sprites 2-5 make it across the screen.
        //Turn on sprite x overflow for sprites 2-5. 
        SPRITE_X_OVERFLOW = 60;   
        for (index=0; index <=88; index++) {
            SPRITE_2_X=index;
            SPRITE_3_X=index;
            SPRITE_4_X=index;
            SPRITE_5_X=index;
            if (KEY_COUNT > 0) break; //Exit on keypress
            //Raster delay
            RASTER();
        }
        SPRITE_ENABLE=0; //Hide sprites while turning the overflow off.
        SPRITE_X_OVERFLOW = 0; //Turn off sprite x overflow.    
        remove_stars();
    }
}

void set_star_colors(void) {
    unsigned int index=0;
    for (index=0xD817; index<0xDBE7; index++) {
        POKE(index,rand()%15+1);
    }   
}

void finalize(void) {
    SPRITE_ENABLE=0; //Hide sprites
    //Restore original screen colors.
    bgcolor(save_background_color);
    bordercolor(save_bordercolor);
    KEY_COUNT=0; //Clear keyboard buffer.
    clrscr();
    //Return to uppercase by clearing the 2 LSBs.
    VIC_MEM_CONTROL_REG &= VIC_UPPER; 
}

void plot_stars(void) {
    unsigned char index=0;
    for (index=0; index<20; index++) {
		//One of the nice things about POKE is that we can
		//POKE memory addresses directly without declaring
		//pointers.
        starat[index]=rand()%977+1047;
        POKE(starat[index], 46);
    }
}

void remove_stars(void) {
    unsigned char index=0;
    for (index=0; index<20; index++) {
        POKE(starat[index],32);
    }
}

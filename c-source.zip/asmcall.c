void hello(void);

//14 byte array ending in 0.
unsigned char msg[14] = "Hello, World!\0";

int main(void) {
    hello();
    return 0;
}

/*
 * Clear screen and print "Hello, World!".
 */
void hello(void) {
    asm("lda #$93");
    asm("jsr $ffd2");
    asm("ldx #0");
    asm("loop:"); //Notice the trailing colon.
    asm("lda _msg,x"); //Notice the leading underscore.
    asm("beq exit");
    asm("jsr $ffd2");
    asm("inx");
    asm("jmp loop");
    asm("exit:"); //Notice the trailing colon.
}

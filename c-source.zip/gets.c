#include <stdio.h>

int main(void) {
    char name[20];

    printf("What is your name? ");
    gets(name);

    printf("Hello, %s!\n", name);

    return 0;
}

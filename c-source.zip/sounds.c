#include <stdio.h>
#include <conio.h>
#include "cinc64.h"

/*
 * Just to be different this time, let's arrange our functions
 * in a way that frees us from prototyping.
 */
void silence(void) {
	//Initialize SID
	unsigned char* s_index=0; //sid pointer index
    for (s_index=&SID_START; s_index<=&SID_END; s_index++) {
        *s_index=0;
    } 
}

void init(void) {
    clrscr();
    silence(); //Initialize SID  
    SID_VOLUME=15;
}

void intruder(void) {
    unsigned char index=0;
    
    VOICE_1_AD=64;
    VOICE_1_SR=242;
    VOICE_1_PULSE_HIGH=12;
    VOICE_1_PULSE_LOW=100;
    VOICE_1_WAVEFORM=65;
    
	puts("Press any key to stop this infernal\nracket.");

    while (!kbhit()) {
        for (index=10; index<=140; index+=2) {
            VOICE_1_HIGH_FREQ=index;
            VOICE_1_LOW_FREQ=index;
            WAIT(1); 
            if (kbhit()) break;
        }
    }

    cgetc(); //Remove the waiting keystroke.
    VOICE_1_WAVEFORM=64;
}

void dive_bomber(void) {
	unsigned char high=0, low=0;
	puts("Dive bomber!");
	VOICE_1_PULSE_HIGH=4;
    VOICE_1_PULSE_LOW=1;
    VOICE_1_AD=68;
    VOICE_1_SR=240;
	VOICE_1_WAVEFORM=65;
	for (high=7; high<11; high++) {
		for (low=0; low<255; low++) {
			VOICE_1_HIGH_FREQ=high;
			VOICE_1_LOW_FREQ=low;
			WAIT(1);
		}
	}
	VOICE_1_WAVEFORM=64;    
}

void blast_off(void) {
	unsigned char vol=0;
	puts("Blast Off!");
	VOICE_1_AD=31;
    VOICE_1_SR=255;
    VOICE_1_HIGH_FREQ=7;
    VOICE_1_LOW_FREQ=16;
    VOICE_1_WAVEFORM=129;
    for (vol=15; vol>0; vol--) {
		SID_VOLUME=vol;
		WAIT(10);
	}
    VOICE_1_WAVEFORM=128;
}

void splash(void) {
	puts("Splash!");
	SID_VOLUME=15;
	VOICE_1_AD=155;
	VOICE_1_SR=9;
	VOICE_2_AD=145;
	VOICE_2_SR=12;
	VOICE_1_HIGH_FREQ=36;
	VOICE_1_LOW_FREQ=40;
	VOICE_2_HIGH_FREQ=21;
	VOICE_2_LOW_FREQ=116;
	VOICE_1_WAVEFORM=129;
	VOICE_2_WAVEFORM=129;
	WAIT (200);
	VOICE_1_WAVEFORM=128;
	VOICE_2_WAVEFORM=128;
}

void vitals(void) {
	unsigned char rep=0, beat=0;
	puts("He's still alive, Jim.");
	VOICE_1_AD=127;
	VOICE_1_SR=16;
	VOICE_1_HIGH_FREQ=34;
	VOICE_1_PULSE_HIGH=10;
	VOICE_1_PULSE_LOW=128;
	VOICE_1_LOW_FREQ=255;
	for (rep=0; rep<5; rep++) {
		for(beat=0; beat<2; beat++) {
			VOICE_1_WAVEFORM=65;
			WAIT(30);
			VOICE_1_WAVEFORM=64;
			WAIT(10);
		}
		WAIT(60);
	}
}

int main(void) {
    init();
    intruder();
    WAIT(30);
    dive_bomber();
    WAIT(30);
    blast_off();
    WAIT(30);
    splash();
    WAIT(30);
    vitals();
    silence();
    return 0;
}

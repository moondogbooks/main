#include <stdio.h>

char* get_avg_test_score(unsigned int);

//You can define a symbolic name for any value
#define NUMBER_OF_TESTS 4

typedef struct {
	unsigned int id;
    unsigned char* last_name;
    unsigned char* first_name;
    unsigned char test_scores[NUMBER_OF_TESTS];
} student_record;

student_record students[5] = {
	{1,"Watanabe","Toshiro", {88,79,91,94}},
	{2,"Cole","Johnny", {74,69,88,79}},
	{3,"Ryan","Pamela", {76,81,94,83}},
	{4,"Poole","Amber", {83,79,93,92}},
	{5,"", "Atlas", {100,100,100,100}}
};

int main(void) {
	//To get the element count, we divide the size of the entire array
	//by the size of the first element. Since both first and last names
	//are declared as char pointers, they are the same size no matter
	//the length of the name that they are pointing to.
	unsigned int class_size = sizeof(students) / sizeof(students[0]);
	unsigned int index1=0, index2=0;
	unsigned int total_test_scores=0;
	for (index1=0; index1<class_size; index1++) {
		total_test_scores=0;
		for (index2=0; index2<NUMBER_OF_TESTS; index2++) {
			total_test_scores+=students[index1].test_scores[index2];
		}   
		printf("%s %s avg test score = %s\n",
		  students[index1].first_name,
		  students[index1].last_name,
		  get_avg_test_score(total_test_scores));
	}
    return 0;
}

/*
 * Since cc65 does not support floating-point arithmetic, we will
 * have to be creative. Multiply the dividend by 100. Perform the
 * division on this enlarged number, and then divide the answer by
 * 100. The integer part and the remainder are joined together in
 * a string with a decimal separating the two.
 */
char* get_avg_test_score(unsigned int dividend) {
	//We want result to remain intact after exiting the function.
	//static will keep result in memory.
	//A static function variable will persist in memory even when
	//the function call is over.
    static char result[8]; 
    unsigned int total;
    total = dividend * 100 / NUMBER_OF_TESTS;
    //sprintf prints to an array of chars.
    //%02u prints at least 2 digits, adding a leading zero if needed.
    sprintf(result, "%u.%02u", total / 100, total % 100);
    return result;
}



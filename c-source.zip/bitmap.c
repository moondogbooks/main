#include <tgi.h>
#include <conio.h>
#include "cinc64.h"

void rectangle(unsigned int, unsigned int, unsigned int,
   unsigned int);

static const unsigned char palette[2] = {
    TGI_COLOR_WHITE,
    TGI_COLOR_BLUE
};

int main(void)
{
    unsigned int index=0;

    tgi_install(tgi_static_stddrv);
    tgi_init();
    tgi_setpalette(palette);
    tgi_setcolor(1);   //Draw with palette entry 1.

    tgi_clear(); //Clear the screen.

    //Plot a single pixel.
    tgi_setpixel(80, 50); //X, Y
    WAIT(120);

    //Erase pixel.
    tgi_setcolor(0); //Draw with background color.
    tgi_setpixel(80, 50);

    //Draw a line.
    tgi_setcolor(1);
    tgi_line(0, 0, 160, 50); //X1, Y1, X2, Y2

    //Draw another line starting from the cursor position and
    //ending at X,Y.
    tgi_lineto(319, 0); //X, Y

    //Draw a third line.
    //Now honestly, how many of you had to STAND IN THE CORNER!?
    tgi_line(160, 50, 160, 199);

    WAIT(120);

    tgi_clear(); //Clear the screen.
    for (index=0; index<=150; index+=30) {
        rectangle(index, 0, 319-index, 199);
    }

    WAIT(120);
    tgi_clear();

    //Draw a filled rectangle.
    tgi_bar(20, 20, 300, 180); //X1, Y1, X2, Y2

    WAIT(120);
    tgi_clear();

    //Draw a circle.
    tgi_circle(160, 100, 40); //X, Y, Radius

    //Draw ellipses.
    tgi_ellipse(160, 100, 80, 20); //X, Y, X Radius, Y Radius
    tgi_ellipse(160, 100, 80, 40);

    WAIT(120);
    tgi_clear();

    //Parameters:
    //X, Y, X Radius, Y Radius, Start Angle, End Angle
    //The ending angle should be greater than the starting angle.
    tgi_pieslice(120, 50, 40, 20, 45, 360);
    tgi_pieslice(210, 80, 40, 20, 0, 45);

    WAIT(120);
    
    tgi_clear();
    //Draw the upper half of an ellipse.
	//X, Y, X Radius, Y Radius, Start Angle, End Angle
	tgi_arc(160, 100, 160, 100, 0, 180);
	tgi_line(0,100,319,100);

	WAIT(120);

    //Return to text mode.
    tgi_done();
    tgi_unload();

    cputs("Show's over.");

    return 0;
}

//Oddly enough, there isn't a rectangle function.
//But we can make one using four lines.
void rectangle(unsigned int x1, unsigned int y1, unsigned int x2,
   unsigned int y2) {
    tgi_line(x1, y1, x2, y1);
    tgi_line(x1, y2, x2, y2);
    tgi_line(x1, y1, x1, y2);
    tgi_line(x2, y1, x2, y2);
}

#include<conio.h>
#include<stdio.h>

void print_message(unsigned char, unsigned char, unsigned char*);

int main(void) {
    unsigned char* mytext = "How now brown chow?";
    clrscr(); //The prototype is in conio.h.
    print_message(5,2,"Hello, World!");
    print_message(7,3,mytext);
    return 0;
}

void print_message(unsigned char col, unsigned char row, unsigned char* message) {
    gotoxy(col,row);
    printf("%s", message); //Use %s to print a 'string'.
}





#include <c64.h>
#include <conio.h>
#define KEY_COUNT *(unsigned char*)0x00C6

unsigned char save_backcolor=0;
unsigned char save_bordercolor=0;

void init(void);
void animate(void);
void finalize(void);
void raster_wait(void);

int main(void) {
    init();
    animate();
    finalize();
    return 0;
}

void init(void) {
    unsigned int index=0;
    unsigned int sprite_number=1;
    clrscr();
    save_backcolor=bgcolor(COLOR_BLACK);
    save_bordercolor=bordercolor(COLOR_WHITE);
    //Initialize sprite coordinates.
    /*
		The U tells cc65 to treat the constants (53248 and 53264)
		as unsigned ints. Without the U, cc65 treats decimal
		constants larger than 32767 as signed longs, which
		would result in a warning.
     */ 
    for (index=53248U;index<=53264U;index++) {
        *(unsigned char*)index = 0;
    }
    //No sprite expansion.
    *(unsigned char *)53271U=0;
    *(unsigned char *)53277U=0;
    //Define sprites as solid rectangles.
    for (index=0; index<=62;index++) {
        *(unsigned char*)(index+832)=255;
    }
    //Set sprite data location for all sprites to 832(13*64).
    for (index=2040; index<=2047; index++) {
        *(unsigned char *)index=13;
    }
    //Set sprite X position for all sprites.
    for (index=53248U; index <=53262U; index+=2) {
        *(unsigned char*)index=sprite_number*30;
        sprite_number++;
    }
    //Turn on all sprites;
    *(unsigned char*)53269U=255;
}

void animate(void) {
    unsigned int index=0;
    unsigned int spritey=0;
    while(KEY_COUNT == 0) {
        for (spritey=0; spritey <= 250; spritey++) {
            for (index=53249U; index <=53263U; index+=2) {
                *(unsigned char*)index=spritey;
            }
            if (KEY_COUNT > 0) break;
            raster_wait();
        }
    }
}

void finalize(void) {
    *(unsigned char*)53269U=0;
    bgcolor(save_backcolor);
    bordercolor(save_bordercolor);
    KEY_COUNT=0;
}

/*
    Wait for the raster to reach line 256.
    The assembly language equivalent is:
       NF1      BIT $D011
                BMI NF1
       NF2      BIT $D011
                BPL NF2
                
    This would certainly make a good candidate for 
    a library function. Perhaps in a library called 
    graphics? How about all of those pointers we are 
    referencing. Perhaps they could go into a custom
    header too?
*/
void raster_wait(void) {
     while (*(unsigned char*)0xD011>=128) {}
     while (*(unsigned char*)0xD011<128) {}
}

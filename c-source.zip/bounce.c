#include <conio.h>
#include <c64.h>
//Remember that this memory location contains the
//number of items waiting in the keyboard buffer.
#define KEY_COUNT *(unsigned char*)0x00C6

void raster_wait(void);

int main(void) {
    unsigned char save_backcolor=bgcolor(COLOR_BLACK);
    unsigned char save_bordercolor=bordercolor(COLOR_WHITE);
    unsigned char save_textcolor=textcolor(COLOR_WHITE);
    unsigned char x=0;
    unsigned char y=0;
    signed char dx=1; //X direction
    signed char dy=1; //Y direction
    unsigned char* screen=(unsigned char*)0x0400;

    clrscr();
    //Clear bits 0 and 1 in D018.
    //This will set the default character set.
    *(unsigned char*)0xD018 &=252;

    //Loop while the keyboard buffer is empty.
    while (KEY_COUNT==0) {
        *(screen+40*y+x) = 81; //place ball
        
        raster_wait();

        *(screen+40*y+x)=32; //Remove ball

        x+=dx;
        if (x<=0 || x>=39) dx=-dx;
        y+=dy;
        if (y<=0 || y>=24) dy=-dy;
    }
    KEY_COUNT=0; //Prevent our keystroke from showing after exit.
    bgcolor(save_backcolor);
    bordercolor(save_bordercolor);
    textcolor(save_textcolor);
    return 1;
}

/*
    Wait for the raster to reach line 256.
    The assembly language equivalent is:
       NF1      BIT $D011
                BMI NF1
       NF2      BIT $D011
                BPL NF2
*/
void raster_wait(void) {
     while (*(unsigned char*)0xD011>=128) {}
     while (*(unsigned char*)0xD011<128) {}
}

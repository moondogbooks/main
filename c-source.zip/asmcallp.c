void fillscreen(unsigned char);

int main(void) {
	unsigned char index=0;
	do {
		fillscreen(index);
		index++;
	} while(index !=0);
	asm("lda #$93");
	asm("jsr $ffd2");
    return 0;
}

/*
 * There I go again with the screenfill!
 * But seriously, compare this to the
 * C screenfill at the beginning of the book.
 */ 
void fillscreen(unsigned char code) {
	*(unsigned char*)0xfa = code;
	asm("lda $fa");
	asm("ldx #0");
	asm("loop:");
	asm("sta $0400,x");
	asm("sta $04fa,x");
	asm("sta $05f4,x");
	asm("sta $06ee,x");
	asm("inx");
	asm("cpx #$fa");
	asm("bne loop");
}

.export _fillmem
.export _pause
.import popax

;You can use macros too!
;Wait for 10 jiffies.
.macro jiffywait
        sta $fa
        lda $a2
        clc
        adc $fa
@wait:
        cmp $a2
        bne @wait
.endmacro
;@ makes labels local, so you don't need to worry about conflicts.

_fillmem:
        ;value arrived in A.
        sta $fa

        ;Pop end address.
        jsr popax
        sta $fb             ;Low byte
        stx $fc             ;High byte

        ;Pop start address.
        jsr popax
        sta $fd             ;Low byte
        stx $fe             ;High byte

        ;Fill memory from start through end.
        ldy #0

loop:
        lda $fa
        sta ($fd),y

        ;Have we reached the ending address?
        lda $fd
        cmp $fb
        bne next
        lda $fe
        cmp $fc
        beq done

next:
        inc $fd
        bne loop
        inc $fe
        jmp loop

done:
        rts
        
_pause:
	;Let's call a macro just because we can.
	jiffywait 
	rts

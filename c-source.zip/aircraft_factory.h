#ifndef AIRCRAFT_FACTORY_H
#define AIRCRAFT_FACTORY_H

void load_aircraft_shape_data(unsigned int starting_address);
void make_airplane(unsigned char sprite_number, 
	unsigned char expand_x, unsigned char expand_y);	
void make_chopper(unsigned char sprite_number, 
	unsigned char expand_x, unsigned char expand_y);
void initialize_sprites(void);

#endif

#include <stdio.h>
#include <conio.h>

//Use an enum to create named constants for the C64 colors.
enum {
     BLACK=0,
     WHITE=1,
     RED=2,
     CYAN=3,
     PURPLE=4,
     GREEN=5,
     BLUE=6,
     YELLOW=7,
     ORANGE=8,
     BROWN=9,
     LIGHT_RED=10,
     GRAY_1=11,
     GRAY_2=12,
     LIGHT_GREEN=13,
     LIGHT_BLUE=14,
     GRAY_3=15
};

//Use typedef with an enum to create a new variable type.
typedef enum {
	GRADE_FAIL,
	GRADE_PASS,
	GRADE_UNKNOWN
} t_grade;

int main(void) {
    //pointers to c64 registers
    unsigned char* border = (unsigned char*)0xD020;
    unsigned char* screen = (unsigned char*)0xD021;
    unsigned char* text = (unsigned char*)0x0286;

    unsigned char correct_answers=0;
    unsigned char prompt_response=0;
    t_grade grade = GRADE_UNKNOWN; //our new enum type

    //simple alternative to printf 
    puts("do you want to take a test?(y/n)");

    //Keep asking until we get either a yes or no.
    while (prompt_response != 'y' &&
           prompt_response != 'Y' &&
           prompt_response != 'n' &&
           prompt_response != 'N')
    {
        prompt_response = cgetc(); //Accept a single keystroke.
    }

    //Challenge accepted
    if (prompt_response=='y' || prompt_response=='Y')
    {
        unsigned char index=0;
        for (index=1; index<=10; index++) {
            unsigned int product = index*index;
            unsigned int answer=0;
            printf("%d * %d = ",index,index);
            //We are not doing anything fancy here.
            //If you enter non-numeric input, that will 
            //break our test.
            scanf("%u", &answer);
            if (product==answer) {
                puts("correct!");
                correct_answers++;
            } else {
                puts("incorrect");
            }
        }

        //You need to score at least 70% to pass this test.
        if (correct_answers >=7)
           grade = GRADE_PASS;
        else
           grade = GRADE_FAIL;
    }

    clrscr();
    *border = GRAY_3;
    *screen = GREEN;
    *text = WHITE;

    if (grade != GRADE_UNKNOWN)
    {
        //Use %% in printf to print a percent sign.
        printf("You scored %d%%\n", correct_answers*10);
    }

    switch(grade) {
        case GRADE_FAIL:
           puts("You failed!");
           break;
        case GRADE_PASS:
           puts("You passed!");
           break;
        case GRADE_UNKNOWN:
           puts("You have not taken the test.");
           break;
    }

    return 0;
}

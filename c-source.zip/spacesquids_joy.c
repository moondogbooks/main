#include <stdio.h>
#include <conio.h>
#include <c64.h>
#include <stdlib.h>
#include "cinc64.h"

void installtsr(void);
void deinstalltsr(void);
void init(void);
void run(void);
unsigned char animate_frames(unsigned char);
void finalize(void);
void random_pellet(void);
unsigned char check_collision(void);
void read_joy2(void);
void move_player(void);

#define SPRITE_COL (*(unsigned char*)0xD01F)
#define BORDER_COL (*(unsigned char*)0xD020)
#define SP_DATA_PTR0 (*(unsigned char*)0x07F8)
#define SP_DATA_PTR1 (*(unsigned char*)0x07F9)
#define SP_DATA_PTR2 (*(unsigned char*)0x07FA)
#define SP_DATA_PTR3 (*(unsigned char*)0x07FB)
#define Joy2 (*(unsigned char *)0xDC00)

typedef struct {
    unsigned char up;
    unsigned char down;
    unsigned char left;
    unsigned char right;
    unsigned char fire;
} joy_input;

joy_input joy2_flags;

unsigned char alien_shape[] = {
    //Frame 1
    40,0,40,     10,0,160,    2,0,128,
    0,170,0,     2,170,128,   2,235,128,
    2,105,128,   2,235,128,   2,170,128,
    2,150,128,   0,170,0,     0,170,0,
    2,170,128,   2,170,128,   2,170,128,
    2,40,128,    2,40,128,    8,130,32,
    8,130,32,    8,130,32,    0,0,0,0,

    //Frame 2
    0,0,0,       10,0,160,    34,0,136,
    32,170,8,    2,170,128,   2,170,128,
    2,170,128,   2,170,128,   2,170,128,
    2,150,128,   0,170,0,     0,170,0,
    2,170,128,   2,170,128,   2,170,128,
    2,40,128,    2,40,128,    2,40,128,
    2,40,128,    2,40,128,    0,0,0,0,

    //Frame 3
    40,0,40,     10,0,160,    2,0,128,
    0,170,0,     2,170,128,   2,235,128,
    2,105,128,   2,235,128,   2,170,128,
    2,150,128,   0,170,0,     0,170,0,
    0,170,0,     0,170,0,     0,170,0,
    0,170,0,     0,170,0,     0,170,0,
    0,170,0,     0,170,0,     0,0,0,0,

    //Frame 4 (Pellet 1)
    10,0,160,    2,0,128,     2,0,128,
    0,170,0,     2,170,128,   2,170,128,
    2,105,128,   2,170,128,   2,85,128,
    2,150,128,   0,170,0,     0,170,0,
    0,170,0,     0,170,0,     0,170,0,
    0,170,0,     2,40,128,    10,40,160,
    34,40,136,   130,40,130,  0,0,0,0,

    //Frame 5 (Pellet 2)
    2,0,128,     2,0,128,     2,0,128,
    0,170,0,     2,170,128,   2,40,128,
    2,105,128,   2,20,128,    2,150,128,
    2,150,128,   0,170,0,     0,170,0,
    0,170,0,     128,170,2,   32,170,8,
    8,170,32,    2,40,128,    170,40,170,
    2,40,128,    0,40,0,      0,0,0,0,

    //Frame 6 (Pellet 3)
    0,0,0,       0,0,0,       2,0,128,
    8,170,32,    34,170,136,  130,170,130,
    2,170,128,   2,170,128,   2,150,128,
    34,170,136,  8,170,32,    8,170,32,
    8,170,32,    40,170,40,   34,170,136,
    8,170,32,    2,40,128,    2,40,128,
    0,40,0,      0,40,0,      0,0,0,0
};

unsigned char sp0_col=0,sp1_col=0,sp2_col=0,sp3_col=0;

//Multi-color sprite example
int main() {
    init();
    while (joy2_flags.fire==0) {
        run();
    }
    finalize();
    return 0;
}

void init(void) {
    unsigned int index=0;
    unsigned long ti; //internal clock
    ti  = LOW_CLOCK;
    ti |= (unsigned long)MID_CLOCK << 8;
    ti |= (unsigned long)HIGH_CLOCK << 16;
    srand(ti); //Seed random number generator using the 24-bit internal
               //clock at $A0-$A2. 
    VIC_MEM_CONTROL_REG &= VIC_UPPER;
    BACKGROUND_COLOR=COLOR_BLACK;
    BORDER_COLOR=COLOR_WHITE;
    TEXT_COLOR=COLOR_WHITE;

    //Initialize sprite coordinates.
    for (index=SPRITE_0_X;index<=SPRITE_X_OVERFLOW;index++) {
        *(unsigned char*)index = 0;
    }
    //Set Sprite Colors
    SPRITE_MULTICOLOR_FLAG=15; //Sprites 0-3 are multi-colored sprites.
    SPRITE_MULTICOLOR_REG_0=COLOR_RED; //Multi-color register 0 = 7;
    SPRITE_MULTICOLOR_REG_1=COLOR_WHITE; //Multi-color register 1 = 0;
    SPRITE_COLOR_0=COLOR_GREEN;
    SPRITE_COLOR_1=COLOR_BLUE;
    SPRITE_COLOR_2=COLOR_YELLOW;
    SPRITE_COLOR_3=COLOR_GRAY1;

    //Set sprite data location to 832(13*64) for sprites 0-2.
    animate_frames(1);
    //Load alien shape for sprites.
    for (index=0; index<=383;index++) {
        *(unsigned char*)(index+12800)=alien_shape[index];
    }

    SPRITE_ENABLE=15; //Enable sprites 0-3.
    //No Sprite Expansion
    SPRITE_EXPAND_X=0;
    SPRITE_EXPAND_Y=0;

    SPRITE_0_X=40;
    SPRITE_1_X=120;
    SPRITE_2_X=200;
    SPRITE_3_X=240;
    SPRITE_3_Y=179;
    installtsr(); //Install music playing TSR.
}

void run(void) {
    unsigned int index=0;
    unsigned char frame=1;
	unsigned char tick=0;
    unsigned char speed=0; 
    unsigned char col=0;
    unsigned char colflags = SPRITE_COL; //Be sure to clear the sprite 
										 //collision flags at the start
                                         //of each round.
    sp0_col=0; sp1_col=0; sp2_col=0; sp3_col=0;
    clrscr();
    random_pellet();
    for (index=240; index>=6; index-=speed) {
        if (joy2_flags.fire==1) break;
        read_joy2();
        SPRITE_0_Y=index;
        SPRITE_1_Y=index;
        SPRITE_2_Y=index;
        move_player();
        RASTER();
        tick++;
        if (col==0) col=check_collision();
        if (tick >= 20)
        {
			frame=animate_frames(frame);
			tick=0;
			speed++;
			if (speed > 2) speed=0;
		}
    }
}

void finalize(void) {
    SPRITE_ENABLE=0; //Disable sprites
    KEY_COUNT = 0;
    clrscr();
    BACKGROUND_COLOR=COLOR_BLUE;
    BORDER_COLOR=COLOR_LIGHTBLUE;
    TEXT_COLOR=COLOR_LIGHTBLUE;
    VIC_MEM_CONTROL_REG &= VIC_UPPER; //Return to uppercase.
    deinstalltsr(); //Remove music playing TSR.
}

unsigned char animate_frames(unsigned char movement) {
	SP_DATA_PTR0=199+movement+(sp0_col*3);
    SP_DATA_PTR1=199+movement+(sp1_col*3);
    SP_DATA_PTR2=199+movement+(sp2_col*3);
    SP_DATA_PTR3=199+movement+(sp3_col*3);
	movement++;
	if (movement > 3) movement=1;
	return movement;
}

void read_joy2(void) {
	unsigned char j2 = Joy2; //Read the port once.
    joy2_flags.fire = (j2 & 16)==0;
    joy2_flags.up = (j2 & 1)==0;
    joy2_flags.down = (j2 & 2)==0;
    joy2_flags.left = (j2 & 4)==0;
    joy2_flags.right = (j2 & 8)==0;
}

void move_player(void) {
    if (joy2_flags.up==1) SPRITE_3_Y = SPRITE_3_Y-1;
    if (joy2_flags.down==1) SPRITE_3_Y = SPRITE_3_Y+1;
    if (joy2_flags.left==1) 
    {
		if (SPRITE_3_X > 0) 
		{
			SPRITE_3_X = SPRITE_3_X-1;
		}
		else if (SPRITE_3_X == 0 && ((SPRITE_X_OVERFLOW & 8)==8))
		{
			//It the overflow is on and X is 255, 
			//the sprite is off the screen.
			//No need to hide.
			SPRITE_3_X = 255;
			SPRITE_X_OVERFLOW &= 247;
		}
		else if (SPRITE_3_X == 0 && ((SPRITE_X_OVERFLOW & 8)==0))
		{
			SPRITE_ENABLE &= 247;
			SPRITE_3_X = 86;
			SPRITE_X_OVERFLOW |= 8;
			SPRITE_ENABLE |= 8;
		}
	}
    if (joy2_flags.right==1) 
    {
		if ((((SPRITE_X_OVERFLOW & 8)==0) && SPRITE_3_X < 255) || 
		    (((SPRITE_X_OVERFLOW & 8)==8) && SPRITE_3_X < 86)) 
		    SPRITE_3_X = SPRITE_3_X+1;
		else if (SPRITE_3_X==255) {
			SPRITE_X_OVERFLOW |= 8;
			//It the overflow is on and X is 255, 
			//the sprite is off the screen.
			//No need to hide.			
			SPRITE_3_X=0;
		}
		else if ((SPRITE_X_OVERFLOW & 8)==8) {
			SPRITE_ENABLE &= 247;
			SPRITE_X_OVERFLOW &= 247;
			SPRITE_3_X=0;
			SPRITE_ENABLE |= 8;
		}
	}
}

void random_pellet(void) {
    unsigned int pellet_location=rand() % 1000 + 1024;
    POKE(pellet_location, 81);
}

unsigned char check_collision(void) {
    unsigned char colflags = SPRITE_COL;
    sp0_col=(colflags & 1) == 1;
    sp1_col=(colflags & 2) == 2;
    sp2_col=(colflags & 4) == 4;
    sp3_col=(colflags & 8) == 8;
    if (colflags != 0) clrscr();
    return (colflags != 0);
}

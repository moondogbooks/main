//Minuet in G — J.S. Bach
#include <conio.h>
#include <stdio.h>
#include <c64.h>
#include "cinc64.h"

void init(void);
void play(void);
void finalize(void);
void play_notes(unsigned char, unsigned int);
void play_note(unsigned char, unsigned char, unsigned char, unsigned char);

//Colors 
unsigned char bgclr=0;
unsigned char bdclr=0;
unsigned char txclr=0;

//Control Values
const unsigned char tempo=10; //Lower = faster.
const unsigned char waveform=65; //Pulse
const unsigned char pulse_high_1=8;
const unsigned char pulse_low_1=2;
const unsigned char pulse_high_2=8;
const unsigned char pulse_low_2=2;
const unsigned char volume=15;
const unsigned char attack_decay_1=65;
const unsigned char sustain_release_1=242;
const unsigned char attack_decay_2=65;
const unsigned char sustain_release_2=242;
const unsigned char sl=96; //Note Count

//Musical Notes
//  Play style {0 = silent, 1 = start, 2 = continue playing}
//  Voice High Byte
//  Voice Low Byte 
const unsigned char first_section[] = {
    1,18,209,1,6,71, 2,0,0,2,0,0, 1,12,143,2,0,0,
    1,14,24,2,0,0, 1,15,210,1,7,12, 1,16,195,2,0,0,
    1,18,209,1,7,233, 2,0,0,2,0,0, 1,12,143,2,0,0,
    2,0,0,2,0,0, 1,12,143,2,0,0, 2,0,0,2,0,0,
    1,21,31,1,8,97, 2,0,0,2,0,0, 1,16,195,2,0,0,
    1,18,209,2,0,0, 1,21,31,2,0,0, 1,23,181,2,0,0,
    1,25,30,1,7,233, 2,0,0,2,0,0, 1,12,143,2,0,0,
    2,0,0,2,0,0, 1,12,143,2,0,0, 2,0,0,2,0,0,
    1,16,195,1,7,12, 2,0,0,2,0,0, 1,18,209,2,0,0,
    1,16,195,2,0,0, 1,15,210,2,0,0, 1,14,24,2,0,0,
    1,15,210,1,6,71, 2,0,0,2,0,0, 1,16,195,2,0,0,
    1,15,210,2,0,0, 1,14,24,2,0,0, 1,12,143,2,0,0,
    1,11,218,1,9,104, 2,0,0,2,0,0, 1,12,143,1,7,233,
    1,14,24,2,0,0, 1,15,210,1,6,71, 1,12,143,2,0,0,
    1,14,24,1,9,104, 2,0,0,2,0,0, 1,9,104,2,0,0,
    1,8,97,2,0,0, 1,7,233,2,0,0, 1,7,12,2,0,0,
    1,18,209,1,7,233, 2,0,0,2,0,0, 1,12,143,2,0,0,
    1,14,24,2,0,0, 1,15,210,1,7,12, 1,16,195,2,0,0,
    1,18,209,1,6,71, 2,0,0,2,0,0, 1,12,143,1,7,233,
    2,0,0,2,0,0, 1,12,143,1,7,233, 2,0,0,2,0,0,
    1,21,31,1,8,97, 2,0,0,2,0,0, 1,16,195,2,0,0,
    1,18,209,2,0,0, 1,21,31,2,0,0, 1,23,181,2,0,0,
    1,25,30,1,7,233, 2,0,0,2,0,0, 1,12,143,1,8,97,
    2,0,0,1,7,233, 1,12,143,1,7,12, 2,0,0,1,6,71,
    1,16,195,1,7,12, 2,0,0,2,0,0, 1,18,209,2,0,0,
    1,16,195,2,0,0, 1,15,210,1,7,12, 1,14,24,2,0,0,
    1,15,210,1,6,71, 2,0,0,2,0,0, 1,16,195,2,0,0,
    1,15,210,2,0,0, 1,14,24,1,7,233, 1,12,143,2,0,0,
    1,14,24,1,8,97, 2,0,0,2,0,0, 1,15,210,2,0,0,
    1,14,24,2,0,0, 1,12,143,2,0,0, 1,11,218,2,0,0,
    1,12,143,1,12,143, 2,0,0,2,0,0, 2,0,0,1,9,104,
    2,0,0,2,0,0, 2,0,0,1,6,71, 2,0,0,2,0,0
};

const unsigned char second_section[] = {
    1,31,165,1,12,143, 2,0,0,2,0,0, 1,25,30,2,0,0,
    1,28,49,2,0,0, 1,31,165,2,0,0, 1,25,30,2,0,0,
    1,28,49,1,9,104, 2,0,0,2,0,0, 1,18,209,2,0,0,
    1,21,31,2,0,0, 1,23,181,2,0,0, 1,18,209,2,0,0,
    1,25,30,1,10,143, 2,0,0,2,0,0, 1,21,31,1,12,143,
    1,23,181,2,0,0, 1,25,30,1,10,143, 1,18,209,2,0,0,
    1,17,195,1,14,24, 2,0,0,2,0,0, 1,15,210,2,0,0,
    1,17,195,2,0,0, 1,14,24,2,0,0, 2,0,0,2,0,0,
    1,14,24,1,7,12, 1,15,210,2,0,0, 1,17,195,1,7,233,
    1,18,209,2,0,0, 1,21,31,1,10,143, 1,23,181,2,0,0,
    1,25,30,1,7,233, 2,0,0,2,0,0, 1,23,181,1,9,104,
    2,0,0,2,0,0, 1,21,31,1,8,255, 2,0,0,2,0,0,
    1,23,181,1,9,104, 2,0,0,2,0,0, 1,14,24,1,5,237,
    2,0,0,2,0,0, 1,17,195,1,7,12, 2,0,0,2,0,0,
    1,18,209,1,9,104, 2,0,0,2,0,0, 2,0,0,1,9,104,
    2,0,0,2,0,0, 2,0,0,1,8,97, 2,0,0,2,0,0,
    1,18,209,1,7,233, 2,0,0,2,0,0, 1,12,143,2,0,0,
    1,11,218,2,0,0, 1,12,143,1,7,233, 2,0,0,2,0,0,
    1,21,31,1,8,97, 2,0,0,2,0,0, 1,12,143,2,0,0,
    1,11,218,2,0,0, 1,12,143,2,0,0, 2,0,0,2,0,0,
    1,18,209,1,7,233, 2,0,0,2,0,0, 1,16,195,1,7,12,
    2,0,0,2,0,0, 1,15,210,1,6,71, 2,0,0,2,0,0,
    1,14,24,2,0,0, 1,12,143,2,0,0, 1,11,218,2,0,0,
    1,12,143,2,0,0, 1,14,24,2,0,0, 2,0,0,2,0,0,
    1,9,104,2,0,0, 1,10,143,2,0,0, 1,11,218,2,0,0,
    1,12,143,2,0,0, 1,14,24,2,0,0, 1,15,210,2,0,0,
    1,16,195,1,10,143, 2,0,0,2,0,0, 1,15,210,2,0,0,
    2,0,0,2,0,0, 1,14,24,1,11,218, 2,0,0,2,0,0,
    1,15,210,1,12,143, 2,0,0,2,0,0, 1,12,143,1,7,233,
    2,0,0,2,0,0, 1,14,24,1,11,218, 2,0,0,2,0,0,
    1,25,30,1,12,143, 2,0,0,2,0,0, 2,0,0,1,9,104,
    2,0,0,2,0,0, 2,0,0,1,6,71, 2,0,0,2,0,0
};

int main(void) {
    init();  
    play();  
    finalize();
    return 1;
}

void init(void) {
    unsigned int index=0; //int index
    unsigned char* s_index=0; //sid pointer index
    bgclr = bgcolor(COLOR_BLACK);
    bdclr = bordercolor(COLOR_WHITE);
    txclr = textcolor(COLOR_WHITE); 
    clrscr();
    printf("Minute in G - J.S. Bach");
    //Initialize SID
    for (s_index=&SID_START; s_index<=&SID_END; s_index++) {
        *s_index=0;
    }
    VOICE_1_PULSE_LOW=pulse_low_1;
    VOICE_1_PULSE_HIGH=pulse_high_1;
    VOICE_2_PULSE_LOW=pulse_low_2;
    VOICE_2_PULSE_HIGH=pulse_high_2;
    SID_VOLUME=volume;
    VOICE_1_AD=attack_decay_1;
    VOICE_1_SR=sustain_release_1;
    VOICE_2_AD=attack_decay_1; //Same ADSR for voice 1 and voice 2
    VOICE_2_SR=sustain_release_1;     
}

void play(void) {
    unsigned char index1=0;
    unsigned int index2=0;
    //Play sections
    for (index1=0; index1<=3; index1++) {
        //Play notes
        for(index2=0; index2<sl*6; index2+=6) {
            play_notes(index1, index2);
        }
    }
}

void finalize(void) {
    unsigned char* s_index=0;
    //Initialize SID
    for (s_index=&SID_START; s_index<=&SID_END; s_index++) {
        *s_index=0;
    }
    clrscr();
    bgcolor(bgclr);
    bordercolor(bdclr);
    textcolor(txclr);
    VIC_MEM_CONTROL_REG &=VIC_UPPER; //Standard Uppercase   
}

void play_notes(unsigned char section_index, unsigned int note_index) {
    unsigned char play_style_1=0;
    unsigned char note_high_1=0;
    unsigned char note_low_1=0;
    unsigned char play_style_2=0;
    unsigned char note_high_2=0;
    unsigned char note_low_2=0;
    if (section_index >= 2) {
        //Voice 1
        play_style_1=second_section[note_index];
        note_high_1=second_section[note_index+1];
        note_low_1=second_section[note_index+2];
        //Voice 2
        play_style_2=second_section[note_index+3];
        note_high_2=second_section[note_index+4];
        note_low_2=second_section[note_index+5];
    } else {
        //Voice 1
        play_style_1=first_section[note_index];
        note_high_1=first_section[note_index+1];
        note_low_1=first_section[note_index+2];
        //Voice 2
        play_style_2=first_section[note_index+3];
        note_high_2=first_section[note_index+4];
        note_low_2=first_section[note_index+5];
    }
    if (play_style_1 != 2) play_note(1, play_style_1, note_high_1, note_low_1);
    if (play_style_2 != 2) play_note(2, play_style_2, note_high_2, note_low_2);

    WAIT(tempo);
}

void play_note(unsigned char voice, unsigned char play_style, unsigned char high, unsigned char low) {
    //Silence voice
    switch (voice) {
        case 1:
            VOICE_1_WAVEFORM=waveform-1;
            break;
        case 2:
            VOICE_2_WAVEFORM=waveform-1;
            break;
    }
    //Play note if play_style is not 0.
    if (play_style == 0){
        return;
    } 

    switch (voice) {
        case 1:
            VOICE_1_HIGH_FREQ=high;
            VOICE_1_LOW_FREQ=low;
            VOICE_1_WAVEFORM=waveform;
            break;
        case 2:
            VOICE_2_HIGH_FREQ=high;
            VOICE_2_LOW_FREQ=low;
            VOICE_2_WAVEFORM=waveform;
            break;
    }
}

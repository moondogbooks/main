#include <stdio.h>
#include <conio.h>
#include <c64.h>
#include "cinc64.h"

void init(void);
void run(void);
void finalize(void);
void raster(void);

unsigned char airplane_shape[] = {
    176, 0, 0,
    176, 0, 0,
    188, 0, 0,
    188, 0, 0,
    191, 0, 0,
    255, 255, 192,
    255, 255, 192,
    255, 255, 240,
    247, 119, 112,
    247, 119,  92,
    255, 255, 254,
    255, 255, 254,
    255, 255, 254,
    255, 255, 254,
    255, 255, 254,
    63, 255, 252,
    63, 240, 0,
    47, 192, 0,
    47, 192, 0,
    63, 0, 0,
    63, 0, 0
};

//Multi-color sprite example
int main(void) {
    init();
    while (KEY_COUNT==0) {
        run();
    }
    finalize();
    return 0;
}

void init(void) {
    unsigned int index=0;
    unsigned char* reg;
    clrscr();
    printf("Press any key to exit.");
	//Initialize sprite coordinates and X overflow.
	for (reg = &SPRITE_0_X; reg <= &SPRITE_X_OVERFLOW; reg++) {
		*reg = 0;
	}
    //Set Sprite Colors
    SPRITE_MULTICOLOR_FLAG=15; //Sprites 0-3 are multi-colored sprites.
    SPRITE_MULTICOLOR_REG_0=COLOR_YELLOW;  
    SPRITE_MULTICOLOR_REG_1=COLOR_BLACK;  
    SPRITE_COLOR_0=COLOR_WHITE;  
    SPRITE_COLOR_1=COLOR_RED;  
    SPRITE_COLOR_2=COLOR_LIGHTGREEN;  
    SPRITE_COLOR_3=COLOR_LIGHTBLUE;  

    //Set sprite data location to 832(13*64) for sprites 0-3.
    for (index=2040; index <= 2043; index++) *(unsigned char *)index = 13;
    //Load airplane shape for sprites 0-3.
    for (index=0; index<=62;index++) {
        *(unsigned char*)(index+832)=airplane_shape[index];
    }

    SPRITE_ENABLE=15; //Enable sprites 0-3.
    //Expand sprite 0 X & Y
    SPRITE_EXPAND_X=1;
    SPRITE_EXPAND_Y=1;
    //Set sprite 2 Y position to 100.
    SPRITE_2_Y=100;
    //Set sprite 3 Y position to 140.
    SPRITE_3_Y=140;
}

void run(void) {
    unsigned int index=0;
    ++BACKGROUND_COLOR;
    --BORDER_COLOR;
    SPRITE_X_OVERFLOW=0; //Clear X overflow.
    for (index=30; index<=255; index++) {
        if (KEY_COUNT > 0) break;
        SPRITE_0_X=index; //Sprite 0 X
        SPRITE_1_X=index; //Sprite 1 X
        SPRITE_2_X=index; //Sprite 2 X
        SPRITE_3_X=index; //Sprite 3 X
        SPRITE_0_Y=index; //Sprite 0 Y
        SPRITE_1_Y=280-index; //Sprite 1 Y
        raster();
    }
    if (KEY_COUNT > 0) return;
    //Let sprite 2 and 3 cross the screen.
    SPRITE_X_OVERFLOW=12; //Set X overflow for sprites 2 and 3.
    SPRITE_2_X=0; //Set sprite 2 X = 0.
    SPRITE_3_X=0; //Set sprite 3 X = 0.
    raster();
    for (index=1; index<=88; index++) {
       if (KEY_COUNT > 0) break;
       SPRITE_2_X=index;
       SPRITE_3_X=index;
       raster();
    }
}

void finalize(void) {
    SPRITE_ENABLE=0; //Disable sprites
    KEY_COUNT = 0;
    clrscr();
    BACKGROUND_COLOR=COLOR_BLUE;
    BORDER_COLOR=COLOR_LIGHTBLUE;
    VIC_MEM_CONTROL_REG &= VIC_UPPER; //Return to uppercase.
}

//Raster Delay
void raster(void) {
    while (RASTER_1<128) {}
    while (RASTER_1>=128) {}    
}

#include <stdio.h>
#include <conio.h>
#include "cinc64.h"

int main() {
    unsigned int index=0;
    for (index=1024;index<=2023;index++) {
        *(unsigned char*)index=1;
    }
    set_source(0x400);
    set_destination(0L);
    set_copy_bytes(1000U);
    REU_ACTION=REU_COPY_FROM_C64; //Copy screen ram to reu.

    WAIT(120);
    
    clrscr();

    WAIT(120);
    set_source(0x400);
    set_destination(0L);
    set_copy_bytes(1000U);
    REU_ACTION=REU_COPY_FROM_REU; //Copy reu to screen ram.
    WAIT(120);
    clrscr();
    return 1;
}


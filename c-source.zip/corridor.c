#include <tgi.h>
#include "cinc64.h"

static const unsigned char palette[2] = {
    TGI_COLOR_WHITE,
    TGI_COLOR_BLACK
};

int main(void)
{
    unsigned int index=0;
    unsigned int x=0;
    unsigned int y=0;

    tgi_install(tgi_static_stddrv);
    tgi_init();
    tgi_setpalette(palette);
    tgi_setcolor(1);   /* draw with palette entry 1 */

    tgi_clear();

    for (index=0; index<320; index+=10) {
        tgi_line(0,0,index,199);
        tgi_line(319,0,319-index,199);
        tgi_line(0,199,319-index,0);
        tgi_line(319,199,index,0);
    }
    tgi_bar(154,95,164,105);

    WAIT(180);

    tgi_done();
    tgi_unload();

    return 0;
}


#include <stdio.h>
#include <conio.h>
#include <c64.h>
#include <stdlib.h>
#include "cinc64.h"

void init();
void run();
unsigned char animate_frames(unsigned char);
void finalize();
void raster();
void random_pellet();
unsigned char check_collision();

#define SP_DATA_PTR0 (*(unsigned char*)0x07F8)
#define SP_DATA_PTR1 (*(unsigned char*)0x07F9)
#define SP_DATA_PTR2 (*(unsigned char*)0x07FA)
//Let’s conserve space by putting 3 rows on a single line.
unsigned char alien_shape[] = {
    //Frame 1
    40,0,40,     10,0,160,    2,0,128,
    0,170,0,     2,170,128,   2,235,128,
    2,105,128,   2,235,128,   2,170,128,
    2,150,128,   0,170,0,     0,170,0,
    2,170,128,   2,170,128,   2,170,128,
    2,40,128,    2,40,128,    8,130,32,
    8,130,32,    8,130,32,    0,0,0,0,

    //Frame 2
    0,0,0,       10,0,160,    34,0,136,
    32,170,8,    2,170,128,   2,170,128,
    2,170,128,   2,170,128,   2,170,128,
    2,150,128,   0,170,0,     0,170,0,
    2,170,128,   2,170,128,   2,170,128,
    2,40,128,    2,40,128,    2,40,128,
    2,40,128,    2,40,128,    0,0,0,0,

    //Frame 3
    40,0,40,     10,0,160,    2,0,128,
    0,170,0,     2,170,128,   2,235,128,
    2,105,128,   2,235,128,   2,170,128,
    2,150,128,   0,170,0,     0,170,0,
    0,170,0,     0,170,0,     0,170,0,
    0,170,0,     0,170,0,     0,170,0,
    0,170,0,     0,170,0,     0,0,0,0,

    //Frame 4 (Pellet 1)
    10,0,160,    2,0,128,     2,0,128,
    0,170,0,     2,170,128,   2,170,128,
    2,105,128,   2,170,128,   2,85,128,
    2,150,128,   0,170,0,     0,170,0,
    0,170,0,     0,170,0,     0,170,0,
    0,170,0,     2,40,128,    10,40,160,
    34,40,136,   130,40,130,  0,0,0,0,

    //Frame 5 (Pellet 2)
    2,0,128,     2,0,128,     2,0,128,
    0,170,0,     2,170,128,   2,40,128,
    2,105,128,   2,20,128,    2,150,128,
    2,150,128,   0,170,0,     0,170,0,
    0,170,0,     128,170,2,   32,170,8,
    8,170,32,    2,40,128,    170,40,170,
    2,40,128,    0,40,0,      0,0,0,0,

    //Frame 6 (Pellet 3)
    0,0,0,       0,0,0,       2,0,128,
    8,170,32,    34,170,136,  130,170,130,
    2,170,128,   2,170,128,   2,150,128,
    34,170,136,  8,170,32,    8,170,32,
    8,170,32,    40,170,40,   34,170,136,
    8,170,32,    2,40,128,    2,40,128,
    0,40,0,      0,40,0,      0,0,0,0
};

unsigned char sp0_col=0,sp1_col=0,sp2_col=0;

//Multi-color sprite example
int main() {
    init();
    while (KEY_COUNT==0) {
        run();
    }
    finalize();
    return 1;
}

void init() {
    unsigned int index=0;
    unsigned long ti; //internal clock
    ti  = LOW_CLOCK;
    ti |= (unsigned long)MID_CLOCK << 8;
    ti |= (unsigned long)HIGH_CLOCK << 16;
    srand(ti); //Seed random number generator using the 24-bit internal
               //clock at $A0-$A2. 
    VIC_MEM_CONTROL_REG &= VIC_UPPER;
    BACKGROUND_COLOR=COLOR_BLACK;
    BORDER_COLOR=COLOR_WHITE;
    TEXT_COLOR=COLOR_WHITE;
    //printf("space squids! press any key to exit.");
    //Initialize sprite coordinates.
    for (index=SPRITE_0_X;index<=SPRITE_X_OVERFLOW;index++) {
        *(unsigned char*)index = 0;
    }
    //Set Sprite Colors
    SPRITE_MULTICOLOR_FLAG=7; //Sprites 0-2 are multi-colored sprites.
    SPRITE_MULTICOLOR_REG_0=COLOR_RED; //Multi-color register 0 = 7;
    SPRITE_MULTICOLOR_REG_1=COLOR_WHITE; //Multi-color register 1 = 0;
    SPRITE_COLOR_0=COLOR_GREEN;
    SPRITE_COLOR_1=COLOR_BLUE;
    SPRITE_COLOR_2=COLOR_YELLOW;

    //Set the initial shape for sprites 0-2..
    animate_frames(1);
    //Load alien shape for sprites 0-1.
    for (index=0; index<=383;index++) {
        *(unsigned char*)(index+12800)=alien_shape[index];
    }

    SPRITE_ENABLE=7; //Enable sprites 0-2.
    //No Sprite Expansion
    SPRITE_EXPAND_X=0;
    SPRITE_EXPAND_Y=0;

    SPRITE_0_X=40;
    SPRITE_1_X=120;
    SPRITE_2_X=200;
}

void run() {
    unsigned int index=0;
    unsigned char frame=1;
	unsigned char tick=0;
    unsigned char speed=0; 
    unsigned char col=0;
    //Be sure to clear the sprite collision flags
    //at the start of each round.
    unsigned char colflags = SPRITE_OTHER_COLLISION;                      
    sp0_col=0; sp1_col=0; sp2_col=0;
    clrscr();
    random_pellet();
    for (index=240; index>=6; index-=speed) {
        if (KEY_COUNT > 0) break;
        SPRITE_0_Y=index;
        SPRITE_1_Y=index;
        SPRITE_2_Y=index;
        raster();
        tick++;
        if (col==0) col=check_collision();
        if (tick >= 20)
        {
			frame=animate_frames(frame);
			tick=0;
			speed++;
			if (speed > 2) speed=0;
		}
    }
}

void finalize() {
    SPRITE_ENABLE=0; //Disable sprites
    KEY_COUNT = 0;
    clrscr();
    BACKGROUND_COLOR=COLOR_BLUE;
    BORDER_COLOR=COLOR_LIGHTBLUE;
    TEXT_COLOR=COLOR_LIGHTBLUE;
    VIC_MEM_CONTROL_REG &= VIC_UPPER; //Return to uppercase.
}

unsigned char animate_frames(unsigned char movement) {
	SP_DATA_PTR0=199+movement+(sp0_col*3);
    SP_DATA_PTR1=199+movement+(sp1_col*3);
    SP_DATA_PTR2=199+movement+(sp2_col*3);
	movement++;
	if (movement > 3) movement=1;
	return movement;
}

//Raster Delay
void raster() {
    while (RASTER_1<128) {}
    while (RASTER_1>=128) {}    
}

void random_pellet() {
    unsigned int pellet_location=rand() % 1000 + 1024;
    *((unsigned char*)pellet_location) = 81;
}

unsigned char check_collision() {
    unsigned char colflags = SPRITE_OTHER_COLLISION;
    sp0_col=(colflags & 1) == 1;
    sp1_col=(colflags & 2) == 2;
    sp2_col=(colflags & 4) == 4;
    if (colflags != 0) clrscr();
    return (colflags != 0);
}

#include <stdio.h>
#include <conio.h>
#include "cinc64.h"

void setcolor(unsigned char background_color, 
    unsigned char border_color,
	unsigned char text_color) {
	BACKGROUND_COLOR=background_color;
	BORDER_COLOR=border_color;
	TEXT_COLOR=text_color;
}

void hello(unsigned char x, unsigned char y) {
	clrscr();
	gotoxy(x,y);
    printf("Hello, World!\n");
}

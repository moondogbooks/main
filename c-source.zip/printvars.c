#include<stdio.h>

int main(void) {
    signed char var1 = 0;   //8-bit signed range =-128 to 127
    unsigned char var2 = 0; //8-bit unsigned range = 0 to 255 
    char var3 = 0;          //8-bit unsigned by default.

    /*
       Notice that var1 (signed char) increments from 1 to 127 before dropping to -128.
       From -128, it will increment to -1. 
    */
    for (var2=1; var2!=0; var2++) { 
        /*
           Repeat what is in the curly braces 255 times.
           var2 will be set to 1 for the first iteration.
           var2 will be increased by one in each successive iteration.
           The loop will end when var2 is equal to 0. 
           Once var2 is 255, adding 1 to that value will result in var2 rolling over to 0. 
        */
        var1++; //Increment var1 by 1.
        var3++; //Increment var3 by 1.
        printf("var1 = %d, var2 = %d,  var3 = %d\n", var1, var2, var3);
    }    

    return 0;
}

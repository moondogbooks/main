
.export _hello

_hello: ;Note that the leading underscore is a
        ;requirement when exporting.
		lda #$93
		jsr $ffd2
		ldx #0
loop:   ;A label must end in a colon.
		lda msg,x
		beq exit
		jsr $ffd2
		inx
		jmp loop
exit:
		rts
		
msg:    .byte  "Hello, World!",0



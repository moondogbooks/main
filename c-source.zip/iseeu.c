#include <tgi.h>
#include "cinc64.h"

static const unsigned char palette[2] = {
    TGI_COLOR_BLACK,
    TGI_COLOR_WHITE
};

int main(void)
{
    unsigned int index=0;
    unsigned int nl=40;
    unsigned int x=0;
    unsigned int y=0;

    tgi_install(tgi_static_stddrv);
    tgi_init();
    tgi_setpalette(palette);
    tgi_setcolor(0);   /* draw with palette entry 0 */
    tgi_setcolor(1);   /* draw with palette entry 1 */

    tgi_clear();

    for (index = 0; index < nl; index++) {
        tgi_line(
            0,
            (index * 200) / nl,
            (index * 320) / nl,
            199
        );

        tgi_line(
            (index * 320) / nl, 
            0,
            320,
            (index * 200) / nl
        );
    }

    for (index=1; index<=45; index++) {
         tgi_circle(159,99, index);
    }

    WAIT(180);

    tgi_done();
    tgi_unload();

    return 0;
}

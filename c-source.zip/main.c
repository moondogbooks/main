#include <stdio.h>

int Main(void) {
    printf("This is not the entry point.\n");
    return 0;
}

int main(void) {
    printf("This is the entry point.\n");
    Main();
    return 0;
}

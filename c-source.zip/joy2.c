#include <conio.h>
#include "cinc64.h"

void init(void);
void read_joy2(void);
void move_sprite_x(signed char);
void finalize(void);

typedef struct {
    unsigned char up;
    unsigned char down;
    unsigned char left;
    unsigned char right;
    unsigned char fire;
} joy_input;

joy_input joy2_flags;

int main(void) {
	unsigned char quit=0;
	init();
	while (quit==0) {
		read_joy2();
		//Check Joystick 2 Flags.
		//There is no overflow register for the Y position. Simple.
		if (joy2_flags.up) SPRITE_0_Y--;
		if (joy2_flags.down) SPRITE_0_Y++;
		//The X position is a little more complicated.
		//We have to deal with the overflow register.
		//Move the logic to deal with this into a function.
		if (joy2_flags.left) move_sprite_x(-1);
		if (joy2_flags.right) move_sprite_x(1);
		if (joy2_flags.fire) {
			SPRITE_COLOR_0++;
			//Prevent the sprite from having the same color
			//as the background.
			if (SPRITE_COLOR_0 == BACKGROUND_COLOR) 
			    SPRITE_COLOR_0++;
		}
		if (kbhit()) quit = cgetc() == 'q'; //Press q to quit.
		RASTER();
	}
	finalize();
    return 0;
}

void init(void) {
	unsigned char index=0;
	clrscr();
	//Initialize sprite coordinates.
    SPRITE_X_OVERFLOW=0;
    SPRITE_0_X=24;
    SPRITE_0_Y=50;
    
    //No Sprite Expansion
    SPRITE_EXPAND_X=0;
    SPRITE_EXPAND_Y=0;
    //Define sprite as a solid rectangle.
    for (index=0; index<=62;index++) {
		POKE(index+832,255);
    }
    //Set sprite data location.
    POKE(2040,13);
    
    SPRITE_ENABLE=1; //Enable sprite 0.
}

void read_joy2(void) {
	unsigned char j2 = JOY2; //Read the port once.
    joy2_flags.fire = (j2 & 16)==0;
    joy2_flags.up = (j2 & 1)==0;
    joy2_flags.down = (j2 & 2)==0;
    joy2_flags.left = (j2 & 4)==0;
    joy2_flags.right = (j2 & 8)==0; 
}

void move_sprite_x(signed char x_adjustment) {
	//Move right
	if (x_adjustment == 1) {
		if ((SPRITE_X_OVERFLOW & 1) == 0 && SPRITE_0_X < 255) {
			//Not using the overflow register.
			//X position is less than 255.
			//Moving to the right will not result in an overflow.
			SPRITE_0_X++;
			return;
		}

        if ((SPRITE_X_OVERFLOW & 1) == 0) {
			//X=255, moving right will result in an overflow.
			SPRITE_X_OVERFLOW = 1;
			//Overflow on and X position register = 0
			//Sprite will have the X position of 256.
			SPRITE_0_X = 0;
			return;
		}
		
		if (SPRITE_0_X < 88) {
			//Overflow is on.
			//Do not move more than 88 pixels to the right.
			SPRITE_0_X++;
			return;
		}
		
		//Sprite has moved off of the right side of the screen.
		SPRITE_0_X =0;
		SPRITE_X_OVERFLOW=0;
		return;
	}	
	
	//Move left
	if (SPRITE_0_X > 0) {
		//X position is > 0. OK to move 1 more pixel to the left.
		SPRITE_0_X--;
		return;
	}
	
	if ((SPRITE_X_OVERFLOW & 1) == 1) {
		//X pos = 0 and overflow on.
		//Turn off overflow and set x pos to 255.
		SPRITE_X_OVERFLOW = 0;
		SPRITE_0_X=255;
		return;
	}
	
	//X pos = 0 and overflow off.
	//Sprite has moved off of the left side of the screen.
	SPRITE_X_OVERFLOW = 1;
	SPRITE_0_X=88;
}

void finalize(void) {
	//Turn sprite off.
	SPRITE_ENABLE=0;
}

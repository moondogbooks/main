#ifndef MYLIB_H
#define MYLIB_H

#define BLACK 0
#define WHITE 1
#define RED 2
#define CYAN 3
#define PURPLE 4
#define GREEN 5
#define BLUE 6
#define YELLOW 7
#define ORANGE 8
#define BROWN 9
#define LIGHTRED 10
#define GRAY1 11
#define GRAY2 12
#define LIGHTGREEN 13
#define LIGHTBLUE 14
#define GRAY3 15

void setcolor(unsigned char, unsigned char, unsigned char);
void hello(unsigned char, unsigned char);

#endif

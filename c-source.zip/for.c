#include<stdio.h>

int main(void) {
    unsigned char x=0;
    for(x=0; x<10; x++) {
        if (x >= 5) break;
        printf("%d\n",x);
    }
    return 0;
}


#include <stdio.h>
#include <string.h>
#include <conio.h>

/*
 * Note: You will need to have a disk image
 * mounted on drive 9.
 */

#define DEVICE      9  //The 9 in OPEN 1,9,2
//The next 2 definitions are for the relative file 
//  we are writing to disk.
#define FILE_LFN    1  //Logical file number, the 1 in OPEN 1,9,2
#define FILE_SA     2  //Secondary address, the 2 in OPEN 1,9,2

#define CMD_LFN 15    //Command channel file number.
#define CMD_SA  15    //Secondary address of the command channel.

//Length of a single record with all of its fields
#define RECORD_LEN  64 

#define ID_OFFSET     0 //Starting position of ID
#define ID_LEN        8 //Length of ID

#define NAME_OFFSET   8  //Starting position of name 
#define NAME_LEN      32 //Length of name
  
#define PHONE_OFFSET  40 //Starting position of phone
#define PHONE_LEN     16 //Length of phone

void position_record(unsigned int recnum) {
    unsigned char cmd[5];

    cmd[0] = 'p';         /* REL position command */
    cmd[1] = FILE_SA;     /* secondary address of REL file */
    cmd[2] = recnum;      /* record number low byte */
    cmd[3] = recnum >> 8; /* record number high byte */
    cmd[4] = 1;           /* first byte of record */
    //BASIC: PRINT#15,"p"CHR$(2)CHR$(record low)CHR$(record high)CHR$(1)
    cbm_write(CMD_LFN, cmd, 5); //Write the 5 bytes of cmd to the 
                                // command channel.
}

void copy_field(char *rec, unsigned char offset, unsigned char maxlen, 
    char *text) {
	//Get length of text being written to field.
    unsigned char len = strlen(text); 

    if (len > maxlen) {
        len = maxlen;
    } // Do not write more bytes than the defined field length.

	//Copy len bytes from text to record starting at the 
	//  position offset.
    memcpy(rec + offset, text, len);  
}

void make_record(char *rec, unsigned int id, char *name, char *phone) {
    char temp[8];

    memset(rec, ' ', RECORD_LEN); //Initialize record with spaces.

    sprintf(temp, "%u", id); //Print the id as a string to temp
    
    copy_field(rec, ID_OFFSET, ID_LEN, temp); //Write ID to record  
    copy_field(rec, NAME_OFFSET, NAME_LEN, name); //Write name to record
    copy_field(rec, PHONE_OFFSET, PHONE_LEN, phone); //Write phone...
}

void print_record(char *rec) {
    char id[ID_LEN + 1];
    char name[NAME_LEN + 1];
    char phone[PHONE_LEN + 1];

    memcpy(id, rec + ID_OFFSET, ID_LEN); //Load id of record into id.
    id[ID_LEN] = 0; //Add a string terminator.
	
	//Load name of record into name.
    memcpy(name, rec + NAME_OFFSET, NAME_LEN); 
    name[NAME_LEN] = 0; //Add a string terminator.

	//Load phone # of recording into phone.
    memcpy(phone, rec + PHONE_OFFSET, PHONE_LEN); 
    phone[PHONE_LEN] = 0; //Add a string terminator.

    //Print the three fields belonging to record.
    printf("ID:    %s\n", id);
    printf("Name:  %s\n", name);
    printf("Phone: %s\n\n", phone);
}

int main(void) {
    char record[RECORD_LEN];
    unsigned int recnum;

    static char filename[] = {
        'c','o','n','t','a','c','t','s',
        ',','l',',', RECORD_LEN,
        0
    };

    //Open the command channel. 
    //We use the command channel to position the 
    //  record pointer within the file.
    //BASIC: OPEN 15,9,15
    cbm_open(CMD_LFN, DEVICE, CMD_SA, "");
    //Open the file for writing.
    //BASIC: OPEN 1,9,2,"CONTACTS,L,64"
    cbm_open(FILE_LFN, DEVICE, FILE_SA, filename);
    //Write first record.
    position_record(1);
    make_record(record, 1, "Joe Chow", "602-555-1212");
    cbm_write(FILE_LFN, record, RECORD_LEN);
    //Write second record.
    position_record(2);
    make_record(record, 2, "Toshiro Watanabe", "520-555-3333");
    cbm_write(FILE_LFN, record, RECORD_LEN);
    //Write third record.
    position_record(3);
    make_record(record, 3, "Pamela Ryan", "928-555-9898");
    cbm_write(FILE_LFN, record, RECORD_LEN);
    cbm_close(FILE_LFN); //Close file, writing is complete

    printf("3 REL records written.\n");
    printf("\nPress any key to read records.\n");
    while (cgetc() == 0) { }

    //Open file for reading.
    cbm_open(FILE_LFN, DEVICE, FILE_SA, filename); 
    //Print the three records to the screen.
    for (recnum = 3; recnum > 0; recnum--) {
        //Get record by position number and read.
        position_record(recnum);
        cbm_read(FILE_LFN, record, RECORD_LEN);
        printf("Record %u\n", recnum); //Print record number.
        print_record(record);          //Print record.
    }

    cbm_close(FILE_LFN); //Close file.
    cbm_close(CMD_LFN); //Close the command channel.
    return 0;
}

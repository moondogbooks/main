//cl65 -t c64 -o bin/simon.prg simon.c simon_asm.s simon_data.c
#include <stdio.h>
#include <c64.h>
#include <conio.h>
#include <stdlib.h>
#include <string.h>
#include "simon_data.h"
#include "c64defs.h"

enum 
{
     CENTER_CHAR=59,
     E_NOTE_CHAR=60,
     S_NOTE_CHAR=61,
     LIGHT_CHAR=62
};

typedef enum {
	GRADE_FAIL,
	GRADE_PASS,
	GRADE_GAME_WON,
	GRADE_UNKNOWN
} t_grade_result;

typedef struct {
    unsigned char up;
    unsigned char down;
    unsigned char left;
    unsigned char right;
    unsigned char fire;
} joy_input;

//These values will never change. 
//That is why the are defined as 'const' or constant.
const unsigned char SPRITE_0_X_ORIG=88;
const unsigned char SPRITE_0_Y_ORIG=123;
const unsigned char SPRITE_1_X_ORIG=143;
const unsigned char SPRITE_1_Y_ORIG=123;
const unsigned char SPRITE_2_X_ORIG=128;
const unsigned char SPRITE_2_Y_ORIG=83;
const unsigned char SPRITE_3_X_ORIG=128;
const unsigned char SPRITE_3_Y_ORIG=143;

#define MAX_SEQUENCE 32
#define PLAYTUNE *(unsigned char*)0x00FA 

void installtsr(void);
void deinstalltsr(void);
void init(unsigned char);
unsigned char game_loop(void);
unsigned char game_over(void);
void cleanup(void);
void splash_screen(void);
void load_chars(void);
void build_playfield(void);
void init_sprites(void);
void draw_lights(void);
void generate_random_notes(void);
void display_text(char*, unsigned char, unsigned char);
void display_seclen(void);
void display_score(void);
void wait(unsigned char);
void play_sequence(void);
unsigned char get_player_input(void);
void redo_sequence(unsigned char*);
t_grade_result grade_sequence(void);
void play_note(unsigned char);
void play_up(void);
void play_right(void);
void play_down(void);
void play_left(void);
void correct_sequence(void);
void raster(void);
void read_joy2(void);

unsigned char uc_game_notes[MAX_SEQUENCE];
unsigned char uc_player_notes[MAX_SEQUENCE];
unsigned char uc_game_over=0;
unsigned char uc_sec_length=0;
unsigned int int_score=0;
unsigned char* scr = (unsigned char*)0x0400;
unsigned char* clr = (unsigned char*)0xD800;
joy_input joy2_flags;
t_grade_result seq_results=GRADE_UNKNOWN;


int main(void) {
	unsigned char show_splash=1;
	unsigned char play_again=1;
	unsigned char hard_quit=0;
	while (play_again==1)
	{
		init(show_splash);
		show_splash=0;
		while (uc_game_over==0) {
			hard_quit=game_loop();
		}
		if (hard_quit) { 
			play_again=0;
			SPRITE_ENABLE = 0;
		} else {
			play_again=game_over();
		}
	}
	cleanup();	
    return 0;
}

void init(unsigned char show_splash) {
	uc_game_over=0;
    uc_sec_length=0;
    int_score=0;
	if (show_splash) splash_screen();
	bordercolor(COLOR_GRAY1);
	bgcolor(COLOR_BLACK);
	textcolor(COLOR_WHITE);
	if (show_splash) installtsr();
    SID_VOLUME=15;
    //Set ASDR
    VOICE_1_AD=68;
    VOICE_1_SR=68;
    //Set Pitch
    VOICE_1_LOW_FREQ=75;
    VOICE_1_HIGH_FREQ=34;
	clrscr();
	if (show_splash) load_chars();
	build_playfield();
	generate_random_notes();
}

unsigned char game_loop(void) {
	unsigned char index=0;
	unsigned char hard_quit=0;
	
	while (uc_sec_length < MAX_SEQUENCE && uc_game_over==0) {
		uc_sec_length++;
		
		display_text("get ready", 30, 1);
		wait(120);
		display_text("         ", 30, 1);
		display_seclen();
		display_score();
		play_sequence();
		
		display_text("your turn", 30, 1);
		hard_quit = get_player_input();
		if (hard_quit == 1) break;
		wait(30);
		display_text("answer   ",30,1);
		seq_results = grade_sequence();
		if (seq_results==GRADE_FAIL) {
			PLAYTUNE=2;
			display_text("oops!    ", 30, 1);
			wait(160);
		}
	}
	uc_game_over = 1;
	return hard_quit;
}

unsigned char game_over(void) {
	unsigned char answer=0;
	KEY_COUNT=0;
	SPRITE_ENABLE = 0; //Turn off sprites 0-3.
	clrscr();
	textcolor(COLOR_WHITE);
	revers(0);
	
	display_text("game over", 15, 9);
	display_text("play again(y/n)?", 12, 11);
	if (int_score < 10)
		gotoxy(16,13);
	else
		gotoxy(15,13);
	printf("score: %i", int_score);
	if (seq_results == GRADE_GAME_WON) {
		display_text("you won!!", 15, 15);
	}
	while (answer != 'y' && answer != 'Y' && answer != 'n' && answer != 'N')
	{ 
		answer=cgetc();
	}
	
	return answer=='y' || answer=='Y';
}

void cleanup(void) {
	bordercolor(COLOR_LIGHTBLUE);
	bgcolor(COLOR_BLUE);
	textcolor(COLOR_LIGHTBLUE);
    VIC_MEM_CONTROL_REG &= VIC_UPPER; //Return to uppercase by clearing the 2 lsbs.
	clrscr();
	deinstalltsr();
	VIC_MEMORY_CONTROL = (VIC_MEMORY_CONTROL & 240) | 4; //Restore default chars.
}

void splash_screen(void) {
	bordercolor(COLOR_RED);
	bgcolor(COLOR_WHITE);
	textcolor(COLOR_BLACK);
	clrscr();
	printf("    Simon Plays - John McGinnis 2026\n\n\n");
	printf("Games like Simon Plays are not just fun.");
	printf("They are gentle excersize for the brain.\n");
	printf("Remembering and replaying patterns draws");
	printf("on short-term memory.\n\n");
	printf("Enjoy a few minutes of play for gentle\nmental stimulation");
	printf(" and a fun challange.\n\n");
	printf("        Press any key to begin."); 
	while (cgetc()==0) { }
}

void load_chars(void) {
    unsigned int index=0;
    unsigned char* font_ram = (unsigned char*)0x3800; //Location of new char set
    unsigned char* char_rom = (unsigned char*)0xD000; //Location of existing char set
    unsigned int letter_index=0; //Letter being copied index.
    unsigned int byte_of_char_index=0;
    unsigned int start_of_letter=0; //Address of the start of a letter being copied.
    VIC_MEM_CONTROL_REG &= VIC_UPPER; //Return to uppercase by clearing the 2 lsbs.
    CIA_CONTROL &= 254;  //Select VIC Bank containing new char rom
    IO_REG &= 251; //Set char-in flag.

    memcpy(font_ram, char_rom, 2048); //alternative to for loop below
    /*for (index = 0; index < 2048; index++) {
        font_ram[index] = char_rom[index];
    }*/

    IO_REG |= 4;
    CIA_CONTROL |=1;
    //Point to new character set (14336)
    VIC_MEMORY_CONTROL = (VIC_MEMORY_CONTROL & 240) | 14;

    for (letter_index = 0; letter_index < 41; letter_index++) {
        start_of_letter = 8 + letter_index * 8; 

        if (letter_index > 25) {
            start_of_letter += 168;
        }
        
        //14344 is 14336 + 8 (A (code 1) starts 8 bytes after char 0 )
        for (byte_of_char_index = 0; byte_of_char_index < 8; byte_of_char_index++) {
            font_ram[start_of_letter + byte_of_char_index] = newchars[letter_index * 8 + byte_of_char_index];
            //Create reverse images of new characters.
			font_ram[start_of_letter + (128 * 8) + byte_of_char_index] =
				(unsigned char)~newchars[letter_index * 8 + byte_of_char_index];
        }
    }
}

void build_playfield(void) {
	unsigned char index1=0,index2=0;
	//Paint right side panel.
	for (index1=0; index1<25; index1++) {
		for (index2=30; index2<40; index2++) {
			*(scr+index2+(index1*40)) = 160;
			*(clr+index2+(index1*40)) = 1;
		}
	}
	
	//Draw Title.
	*(scr+46)=E_NOTE_CHAR;
	*(clr+46)=COLOR_WHITE;
	*(scr+47)=S_NOTE_CHAR;  
	*(clr+47)=COLOR_LIGHTRED;
	
	gotoxy(9,1);
	printf("simon plays");
	*(clr+49)=COLOR_BLUE;
	*(clr+50)=COLOR_BLUE;
    *(clr+51)=COLOR_YELLOW;
	*(clr+52)=COLOR_YELLOW;
    *(clr+53)=COLOR_RED;
	
	*(clr+55)=COLOR_GREEN;
	*(clr+56)=COLOR_GREEN;
	*(clr+57)=COLOR_PURPLE;
	*(clr+58)=COLOR_PURPLE;	
	*(clr+59)=COLOR_CYAN;	
	  
	*(scr+61)=S_NOTE_CHAR;   
	*(clr+61)=COLOR_RED;                   
    *(scr+62)=E_NOTE_CHAR;      
    *(clr+62)=COLOR_LIGHTGREEN;
    display_text("1 2 3 4", 11, 23);
    revers(1);
    display_text("score:", 30, 6);
    display_text("secln:", 30, 7);
    init_sprites(); //Draw arrows.
    //Draw arrow center at column 12 and line 10.
    *(scr+(40*10)+14)=CENTER_CHAR; //Joystick Center Char' 
    draw_lights();
}

void init_sprites(void) {
	unsigned char index=0;
	//Load sprite data into memory.
	for (index = 0; index < 63; index++) {
		*(unsigned char *)(14080 + index) = arrow_left[index];
	}
	for (index = 0; index < 63; index++) {
		*(unsigned char *)(14144 + index) = arrow_right[index];
	}
	for (index = 0; index < 63; index++) {
		*(unsigned char *)(14208 + index) = arrow_up[index];
	}
	for (index = 0; index < 63; index++) {
		*(unsigned char *)(14272 + index) = arrow_down[index];
	}

	// Set sprite data pointers.
	*(unsigned char*)2040 = 220;
	*(unsigned char*)2041 = 221;
	*(unsigned char*)2042 = 222;
	*(unsigned char*)2043 = 223; 
    
    SPRITE_EXPAND_X=12; //Expand X of sprites 2 and 3.
    SPRITE_EXPAND_Y=3;  //Expand Y of sprites 0 and 1.
    
    //Set sprite positions.
    SPRITE_0_X=SPRITE_0_X_ORIG;
    SPRITE_0_Y=SPRITE_0_Y_ORIG;
    SPRITE_1_X=SPRITE_1_X_ORIG;
    SPRITE_1_Y=SPRITE_1_Y_ORIG;
    SPRITE_2_X=SPRITE_2_X_ORIG;
    SPRITE_2_Y=SPRITE_2_Y_ORIG;
    SPRITE_3_X=SPRITE_3_X_ORIG;
    SPRITE_3_Y=SPRITE_3_Y_ORIG;
   
    //Set sprite colors.
    SPRITE_COLOR_0 = COLOR_GREEN;
    SPRITE_COLOR_1 = COLOR_BLUE;
    SPRITE_COLOR_2 = COLOR_RED;
    SPRITE_COLOR_3 = COLOR_BROWN;

    SPRITE_ENABLE = 15; //Turn on sprites 0-3.
}

void draw_lights(void) {
	unsigned char index=0;
	//Draw lights along the top and bottom.
	for (index=0; index<30; index++) {
		*(scr+index) = LIGHT_CHAR;
		*(clr+index) = 0; //Turn off lights. We don't want to see them.
		*(scr+(24*40)+index) = LIGHT_CHAR;
		*(clr+(24*40)+index) = 0;
	}
	//Draw lights along the left and right.
	for (index=1; index<24; index++) {
		*(scr+index*40) = LIGHT_CHAR;
		*(clr+index*40) = 0;
		*(scr+index*40+29) = LIGHT_CHAR;
		*(clr+index*40+29) = 0;
	}
}

void generate_random_notes(void) {
	unsigned long ti; //internal clock
	unsigned char index=0;
    ti  = LOW_CLOCK;
    ti |= (unsigned long)MID_CLOCK << 8;
    ti |= (unsigned long)HIGH_CLOCK << 16;
    srand(ti); //Seed random number generator using the 24-bit internal
               //clock at $A0-$A2.  
               	
	for (index=0; index < MAX_SEQUENCE; index++) {
		uc_game_notes[index]=rand()%4+1;
	}
}

void display_text(char* prompt, unsigned char col, unsigned char row) {
	gotoxy(col, row);
	printf("%s",prompt);
}

void display_seclen(void) {
	 gotoxy(37,7);
	 printf("%u", uc_sec_length);
}

void display_score(void) {
	 gotoxy(37,6);
	 printf("%i", int_score);
}

void wait(unsigned char duration) {
    //Lowest byte of the internal clock. Time is stored in jiffies (1/60 sec).
    LOW_CLOCK=0;
    while (LOW_CLOCK < duration); //Wait until duration in jiffies has passed.
}

void play_sequence(void) {
	unsigned char index=0;
	for (index=0; index <uc_sec_length; index++) {
		play_note(uc_game_notes[index]);
	}
}

t_grade_result grade_sequence(void) {
	unsigned char index=0;
	unsigned char fail=0;
	for (index=0; index < uc_sec_length; index++) {
		play_note(uc_game_notes[index]);
		if (uc_player_notes[index]==uc_game_notes[index]) {
			int_score++;
		} else {
			uc_game_over=1;
			fail=1;
			break;
		}
	}
	display_score();
	if (fail==1) return GRADE_FAIL;
	correct_sequence();
	if (fail==0 && uc_sec_length==MAX_SEQUENCE) return GRADE_GAME_WON;
	return GRADE_PASS;
}

unsigned char get_player_input(void) {
	unsigned char index=0;
	unsigned char inpt=0;
	unsigned char hard_quit=0;
	//Clear keyboard buffer.
	while (kbhit()) {
		cgetc();
	}
	
	while (index < uc_sec_length) {
		inpt=0;
		if (kbhit()) {
			inpt=cgetc();
			if (inpt == 'q' || inpt == 'Q') {
				hard_quit=1;
				uc_game_over=1;
				break;
			}
			if (inpt == 'r' || inpt == 'R') {
				redo_sequence(&index); //Pass address of index so that
				continue;              // we may reset its value to 0.
			}
			inpt-=48;
	    }
       
        if (inpt < 1 || inpt > 4)
        {
			read_joy2();
			if (joy2_flags.up) {
				inpt=1;
			} else if (joy2_flags.right) {
				inpt=2;
			} else if (joy2_flags.down) {
				inpt=3;
			} else if (joy2_flags.left) {
				inpt=4;
			} else if (joy2_flags.fire) {
				redo_sequence(&index);
				continue;
			}
		}
		
		if (inpt > 0 && inpt < 5) {
			uc_player_notes[index]=inpt;
			play_note(inpt);
			index++; 
		} 
	}
	return hard_quit;
}

void redo_sequence(unsigned char* index) {
	display_text("redo ok  ", 30, 1);
	*index=0; //Store a zero at the pointers address.
	wait (60);
	play_sequence();
	display_text("your turn", 30, 1);
}

void play_note(unsigned char value) {
     VOICE_1_WAVEFORM=33;
     switch (value)
     {
		 case 1: 
		     VOICE_1_HIGH_FREQ = *c_note;
			 VOICE_1_LOW_FREQ = *(c_note+1);
		     play_up(); 
		     break;
		 case 2:
		     VOICE_1_HIGH_FREQ = *d_note;
			 VOICE_1_LOW_FREQ = *(d_note+1);
		     play_right();
		     break;
		 case 3:
		     VOICE_1_HIGH_FREQ = *f_note;
			 VOICE_1_LOW_FREQ = *(f_note+1);
		     play_down();
		     break;
		 case 4:
		 	 VOICE_1_HIGH_FREQ = *g_note;
			 VOICE_1_LOW_FREQ = *(g_note+1);
		     play_left();
		     break;  
	 }
	 VOICE_1_WAVEFORM=32;
}

void play_up(void) {
	unsigned char index=0;
	SPRITE_COLOR_2 = COLOR_LIGHTRED;
	bordercolor(COLOR_LIGHTRED);
	*(clr+(40*10)+14)=COLOR_LIGHTRED; //Joystick Center
	*(clr+(40*23)+11)=COLOR_LIGHTRED; //Bottom Number 
	for (index=0; index<38; index++) {
		SPRITE_2_Y-=1;
		raster();
	}
	SPRITE_2_Y = SPRITE_2_Y_ORIG;
	SPRITE_COLOR_2 = COLOR_RED;
	bordercolor(COLOR_GRAY1);
	*(clr+(40*10)+14)=COLOR_WHITE;
	*(clr+(40*23)+11)=COLOR_WHITE;
}

void play_right(void) {
	unsigned char index=0;
	SPRITE_COLOR_1 = COLOR_LIGHTBLUE;
	bordercolor(COLOR_LIGHTBLUE);
	*(clr+(40*10)+14)=COLOR_LIGHTBLUE; //Joystick Center
	*(clr+(40*23)+13)=COLOR_LIGHTBLUE; //Bottom Number 
	for (index=0; index<38; index++) {
		SPRITE_1_X+=1;
		raster();
	}
	SPRITE_1_X = SPRITE_1_X_ORIG;
	SPRITE_COLOR_1 = COLOR_BLUE;
	bordercolor(COLOR_GRAY1);
	*(clr+(40*10)+14)=COLOR_WHITE;
	*(clr+(40*23)+13)=COLOR_WHITE;
}

void play_down(void) {
	unsigned char index=0;
	SPRITE_COLOR_3 = COLOR_ORANGE;
	bordercolor(COLOR_ORANGE);
	*(clr+(40*10)+14)=COLOR_ORANGE; //Joystick Center
	*(clr+(40*23)+15)=COLOR_ORANGE; //Bottom Number
	for (index=0; index<38; index++) {
		SPRITE_3_Y+=1;
		raster();
	}
	SPRITE_3_Y = SPRITE_3_Y_ORIG;
	SPRITE_COLOR_3 = COLOR_BROWN;
	bordercolor(COLOR_GRAY1);
	*(clr+(40*10)+14)=COLOR_WHITE;
	*(clr+(40*23)+15)=COLOR_WHITE;
}

void play_left(void) {
	unsigned char index=0;
	SPRITE_COLOR_0 = COLOR_LIGHTGREEN;
	bordercolor(COLOR_LIGHTGREEN);
	*(clr+(40*10)+14)=COLOR_LIGHTGREEN; //Joystick Center
	*(clr+(40*23)+17)=COLOR_LIGHTBLUE; //Bottom Number
	for (index=0; index<38; index++) {
		SPRITE_0_X-=1;
		raster();
	}
	SPRITE_0_X = SPRITE_0_X_ORIG;
	SPRITE_COLOR_0 = COLOR_GREEN;
	bordercolor(COLOR_GRAY1);
	*(clr+(40*10)+14)=COLOR_WHITE;
	*(clr+(40*23)+17)=COLOR_WHITE;
}

void correct_sequence(void) {
	unsigned char index1=0,index2=0;
	unsigned char color=0;
	
	PLAYTUNE=1;
	display_text("correct! ", 30, 1);
	//Turn on the lights.
	while (index2 < 40) {
		for (index1=0; index1<30; index1++) {
			*(clr+index1) = ++color; 
			*(clr+(24*40)+index1) = color;
			if (index1<24) {
			  *(clr+index1*40) = color;
			  *(clr+index1*40+29) = color;
			}
		}
		wait(1);
		index2++;
	}

	//Turn off the lights.
	for (index1=0; index1<30; index1++) {
		*(clr+index1) = 0; 
		*(clr+(24*40)+index1) = 0;
	}
	for (index1=1; index1<24; index1++) {
		*(clr+index1*40) = 0;
		*(clr+index1*40+29) = 0;
	}
}

void raster(void) {
   while (RASTER_1<128) {}
   while (RASTER_1>=128) {}
}

void read_joy2() {
	unsigned char j2 = Joy2; //Read the port once and use the value 5 times.
    joy2_flags.fire = (j2 & 16)==0;
    joy2_flags.up = (j2 & 1)==0;
    joy2_flags.down = (j2 & 2)==0;
    joy2_flags.left = (j2 & 4)==0;
    joy2_flags.right = (j2 & 8)==0;
}

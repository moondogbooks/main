.export _installtsr
.export _deinstalltsr

playtune = $FA

.macro poke addr, value
    lda #value
    sta addr
.endmacro

_installtsr:
    sei
    jsr initsound

    lda #<musicplayer
    sta $0314
    lda #>musicplayer
    sta $0315

    cli
    rts

_deinstalltsr:
    sei
    jsr initsound ; Silence on exit
    lda #$31
    sta $0314
    lda #$ea
    sta $0315
    cli
    rts

initsound:
    ;Initialize SID registers
    ldx #25
    lda #0
@loop: ;The @ makes the label local. Loop is such a generic name for a label.
    sta $d3ff,x
    dex
    bne @loop

    poke $d418, 15       ; Volume
    poke $d413, 155      ; Voice 3 attack/decay
    poke $d414, 9        ; Voice 3 sustain/release
    poke tuneti, 0
    poke tuneidx, 0
    poke noteon, 0
    rts

;We will run this 60 times a second. It is attached to the timed interrupt at $EA31.
musicplayer:
		;check play music flag
		;exit if 0
		lda playtune
		beq @donotplay
		cmp #1
		bne @fail
		jsr playcharge
		jmp $ea31
@fail:
		jsr playfail
@donotplay:
		jmp $ea31
		
playcharge:
		ldx tuneidx; load tune index
		lda noteon
		beq @startnote ;start note
		clc
		lda charge+2,x; note in prg
		cmp tuneti
		bcs @plyexit ;note not done
		;note is done
		poke $d412,32
		poke noteon,0
		poke tuneti,0
		;advance tune note index
		inc tuneidx
		inc tuneidx
		inc tuneidx
		ldx tuneidx
		;end of tune?
		clc
		cpx #18
		bcc @plyexit ;no
		poke tuneidx,0 ;yes
		poke playtune,0
		rts

@startnote:
		poke noteon,1
		poke tuneti,0

		;play note
		lda charge,x
		sta $d40f
		lda charge+1,x
		sta $d40e
		poke $d412,33
		rts

@plyexit:  
        inc tuneti
		rts

playfail:
		ldx tuneidx; load tune index
		lda noteon
		beq @startnote ;start note
		clc
		lda failtune+2,x; note in prg
		cmp tuneti
		bcs @plyexit ;note not done
		;note is done
		poke $d412,32
		poke noteon,0
		poke tuneti,0
		;advance tune note index
		inc tuneidx
		inc tuneidx
		inc tuneidx
		ldx tuneidx
		;end of tune?
		clc
		cpx #9
		bcc @plyexit ;no
		poke tuneidx,0 ;yes
		poke playtune,0
		rts

@startnote:
		poke noteon,1
		;#poke tuneti,0
		lda #0
		sta tuneti

		;play note
		lda failtune,x
		sta $d40f
		lda failtune+1,x
		sta $d40e
		;#poke $d412,33
		lda #33
		sta $d412
		rts

@plyexit:
        inc tuneti
		rts


;music
noteon:   .byte 0
tuneti:   .byte 0
tuneidx:  .byte 0
charge:   .byte 3,35,10,4,48,10,5,71,10
	 	  .byte 6,71,22,5,71,5,6,71,30
failtune: .byte 6,71,40,3,244,40
		  .byte 3,83,80

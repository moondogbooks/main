#ifndef C64DEFS_H // Include guards to prevent 
#define C64DEFS_H //    h file from being included more than once.

//Controls
#define IO_REG (*(unsigned char*)0x001)
#define CIA_CONTROL (*(unsigned char*)0xDC0E)
#define KEY_COUNT *(unsigned char*)0x00C6
#define RASTER_1 *(unsigned char*)0xD011
#define RASTER_2 *(unsigned char*)0xD012
#define VIC_SCROLL_H (*(unsigned char*)0xD016)
#define VIC_SCROLL_V (*(unsigned char*)0xD011)
#define VIC_MEM_CONTROL_REG (*(unsigned char*)0xD018)
#define VIC_UPPER 252 //And VIC_MEM_CONTROL_REG with 252 for all uppercase.
#define VIC_MIXED 3 //Or VIC_MEM_CONTROL_REG with 3 for mixed case.
#define VIC_MEMORY_CONTROL (*(unsigned char*)0xD018)
#define Joy2 (*(unsigned char *)0xDC00)
#define Joy1 (*(unsigned char *)0xDC01)
//CLOCK
#define LOW_CLOCK (*(unsigned char*)0x00A2)
#define MID_CLOCK (*(unsigned char*)0x00A1)
#define HIGH_CLOCK (*(unsigned char*)0x00A0)
//COLORS
#define BORDER_COLOR (*(unsigned char*)0xD020)
#define BACKGROUND_COLOR (*(unsigned char*)0xD021)
#define TEXT_COLOR (*(unsigned char*)0x0286)
//Sprites
#define SPRITE_ENABLE (*(unsigned char*)0xD015)
//  Location
#define SPRITE_0_X (*(unsigned char*)0xD000)
#define SPRITE_0_Y (*(unsigned char*)0xD001)
#define SPRITE_1_X (*(unsigned char*)0xD002)
#define SPRITE_1_Y (*(unsigned char*)0xD003)
#define SPRITE_2_X (*(unsigned char*)0xD004)
#define SPRITE_2_Y (*(unsigned char*)0xD005)
#define SPRITE_3_X (*(unsigned char*)0xD006)
#define SPRITE_3_Y (*(unsigned char*)0xD007)
#define SPRITE_4_X (*(unsigned char*)0xD008)
#define SPRITE_4_Y (*(unsigned char*)0xD009)
#define SPRITE_5_X (*(unsigned char*)0xD00A)
#define SPRITE_5_Y (*(unsigned char*)0xD00B)
#define SPRITE_6_X (*(unsigned char*)0xD00C)
#define SPRITE_6_Y (*(unsigned char*)0xD00D)
#define SPRITE_7_X (*(unsigned char*)0xD00E)
#define SPRITE_7_Y (*(unsigned char*)0xD00F)
//Sprite X Overflow
#define SPRITE_X_OVERFLOW (*(unsigned char*)0XD010)
//Sprite Expansion
#define SPRITE_EXPAND_X (*(unsigned char*)0xD017)
#define SPRITE_EXPAND_Y (*(unsigned char*)0xD01D)
//Sprite Colors
#define SPRITE_MULTICOLOR_FLAG (*(unsigned char*)0xD01C) //Multi-color flags
#define SPRITE_MULTICOLOR_REG_0 (*(unsigned char*)0xD025) //Multi-color register 0
#define SPRITE_MULTICOLOR_REG_1 (*(unsigned char*)0xD026) //Multi-color register 1
#define SPRITE_COLOR_0 (*(unsigned char*)0xD027) //Sprite 0 Color
#define SPRITE_COLOR_1 (*(unsigned char*)0xD028) //Sprite 1 Color
#define SPRITE_COLOR_2 (*(unsigned char*)0xD029) //Sprite 2 Color
#define SPRITE_COLOR_3 (*(unsigned char*)0xD02A) //Sprite 3 Color
#define SPRITE_COLOR_4 (*(unsigned char*)0xD02B) //Sprite 3 Color
//SID
#define SID_START (*(unsigned char*)0xD400)
#define SID_END (*(unsigned char*)0xD418)
#define VOICE_1_WAVEFORM (*(unsigned char*)0xD404)
#define VOICE_2_WAVEFORM (*(unsigned char*)0xD40B)
#define VOICE_3_WAVEFORM (*(unsigned char*)0xD412)
#define VOICE_1_LOW_FREQ (*(unsigned char*)0xD400)
#define VOICE_1_HIGH_FREQ (*(unsigned char*)0xD401)
#define VOICE_2_LOW_FREQ (*(unsigned char*)0xD407)
#define VOICE_2_HIGH_FREQ (*(unsigned char*)0xD408)
#define VOICE_3_LOW_FREQ (*(unsigned char*)0xD40E)
#define VOICE_3_HIGH_FREQ (*(unsigned char*)0xD40F)
#define VOICE_1_PULSE_LOW (*(unsigned char*)0xD402)
#define VOICE_1_PULSE_HIGH (*(unsigned char*)0xD403)
#define VOICE_2_PULSE_LOW (*(unsigned char*)0xD409)
#define VOICE_2_PULSE_HIGH (*(unsigned char*)0xD40A)
#define VOICE_3_PULSE_LOW (*(unsigned char*)0xD410)
#define VOICE_3_PULSE_HIGH (*(unsigned char*)0xD411)
#define VOICE_1_AD (*(unsigned char*)0xD405)
#define VOICE_1_SR (*(unsigned char*)0xD406)
#define VOICE_2_AD (*(unsigned char*)0xD40C)
#define VOICE_2_SR (*(unsigned char*)0xD40D)
#define VOICE_3_AD (*(unsigned char*)0xD413)
#define VOICE_3_SR (*(unsigned char*)0xD414)
#define SID_VOLUME (*(unsigned char*)0xD418)
//REU
//REU C-64 RAM SOURCE 16-bit (64k)
#define REU_SOURCE_LOW (*(unsigned char*)0xDF02)
#define REU_SOURCE_HIGH (*(unsigned char*)0xDF03)
//REU DESTINATION 24-bit (16M)
#define REU_DEST_LOW (*(unsigned char*)0xDF04)
#define REU_DEST_MID (*(unsigned char*)0xDF05)
#define REU_DEST_HIGH (*(unsigned char*)0xDF06)
//REU Bytes to Copy 16-bit (64k)
#define REU_BYTES_LOW (*(unsigned char*)0xDF07)
#define REU_BYTES_HIGH (*(unsigned char*)0xDF08)
//REU Action
#define REU_ACTION (*(unsigned char*)0xDF01)
#define REU_COPY_FROM_C64 0x90
#define REU_COPY_FROM_REU 0x91

#endif // Include guard endif

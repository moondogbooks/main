#ifndef CHARSET_H // Include guards to prevent 
#define CHARSET_H //    h file from being included more than once.
#define NEWCHARS_SIZE 208

extern unsigned char lightchr[];
extern unsigned char newchars[];
extern unsigned char ctrlcent[];
extern unsigned char notechrs[];
extern unsigned char newnbrs[];
extern unsigned char arrow_left[];
extern unsigned char arrow_right[];
extern unsigned char arrow_up[];
extern unsigned char arrow_down[];
extern unsigned char c_note[];
extern unsigned char d_note[];
extern unsigned char f_note[];
extern unsigned char g_note[];


#endif // Include guard endif

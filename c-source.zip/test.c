#include <conio.h>
#include <time.h>

void fillchar(unsigned char charcode);

int main(void) {
    // Cycle c from 0 to 255.
    unsigned char c = 0;
    unsigned char q=0; //quit flag
    while (q==0)
    {
        fillchar(c);
        c++; //wink, wink, nudge, nudge
        if (c==0) q=1;
    }   
    clrscr();
    return 0;
}

//Remember the screen address on the C64 starts at $0400 or 1024.
void fillchar(unsigned char charcode) {
    unsigned i;
    /*
      While you could technically write the next line as:
          unsigned char* scr = 0x0400;
      you would get the compiler warning:
          Warning: Converting integer to pointer without a cast
    */
    unsigned char* scr = (unsigned char*)0x0400;
    // The cast (unsigned char*) just means we are
    // declaring 0x0400 as an address to use with a pointer to
    // an unsigned char.
    for (i=0; i < 1000; ++i) {
      *scr++ = charcode;
    } 	
    //The for loop above contains an example of pointer arithmetic.
    //With each iteration we are advancing our pointer by 1 character (1 byte). 
}

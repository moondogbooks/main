#include <conio.h>
#include <stdio.h>
#include <string.h>

int main(void) {
    unsigned char* text = "Hello, World!";
    clrscr();
    gotoxy(19-strlen(text)/2,10);
    puts(text);
    return 0;
}

#include "../h/mydefs.h"

void fillchar(unsigned charcode) {
    unsigned i;

    for (i=0; i < 1000; ++i) {
      *(SCREEN_START+i) = charcode;
    } 	
    //The for loop above contains an example of pointer arithmetic.
    //With each iteration we are advancing our pointer 
    //by 1 character (1 byte). 
}

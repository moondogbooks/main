void fillmem(unsigned int start, unsigned int end, unsigned char value);
void pause(unsigned char jiffies);

int main(void) {
	unsigned char index=0;
	do {
		//There I go again!
		fillmem(1024,2023,index);
		pause(5);
		index++;
	} while (index != 0);
	asm("lda #$93");
	asm("jsr $ffd2");
    return 0;
}

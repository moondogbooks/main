#include <stdio.h>
#include <conio.h>
#include "cinc64.h"


void read_joy1(void);
void read_joy2(void);

typedef struct {
    unsigned char up;
    unsigned char down;
    unsigned char left;
    unsigned char right;
    unsigned char fire;
} joy_input;

joy_input joy1_flags;
joy_input joy2_flags;

int main(void) {
	unsigned char quit=0;
	while (quit==0) {
		read_joy1();
		read_joy2();
		//Check Joystick 1 Flags.
		if (joy1_flags.up) printf(" Joy 1: Up ");
		if (joy1_flags.down) printf(" Joy 1: Down ");
		if (joy1_flags.left) printf(" Joy 1: Left ");
		if (joy1_flags.right) printf(" Joy 1: Right ");
		if (joy1_flags.fire) printf(" Joy 1: Fire ");
		//Check Joystick 2 Flags.
		if (joy2_flags.up) printf(" Joy 2: Up ");
		if (joy2_flags.down) printf(" Joy 2: Down ");
		if (joy2_flags.left) printf(" Joy 2: Left ");
		if (joy2_flags.right) printf(" Joy 2: Right ");
		if (joy2_flags.fire) printf(" Joy 2: Fire ");
		if (kbhit()) quit = cgetc() == 'q'; //Press q to quit.
	}
    return 0;
}

//Note: Joystick 1 shares CIA lines with the keyboard.
void read_joy1(void) {	
	unsigned char j1=JOY1; //Read the port once. 
    joy1_flags.fire = (j1 & 16)==0;
    joy1_flags.up = (j1 & 1)==0;
    joy1_flags.down = (j1 & 2)==0;
    joy1_flags.left = (j1 & 4)==0;
    joy1_flags.right = (j1 & 8)==0;
}

void read_joy2(void) {
	unsigned char j2 = JOY2; //Read the port once.
    joy2_flags.fire = (j2 & 16)==0;
    joy2_flags.up = (j2 & 1)==0;
    joy2_flags.down = (j2 & 2)==0;
    joy2_flags.left = (j2 & 4)==0;
    joy2_flags.right = (j2 & 8)==0; 
}

#include <stdio.h>
#include "h/mydefs.h"
/*
   Let's implement the called function before
   calling it. That saves us from needing a prototype.
*/
void prt_message(unsigned char* ptr)
{
    unsigned int index=0;

    for (index = 0; index < 1000; index++) {
        *(SCREEN_START+index) = ptr[index];
    }
}

int main(void)
{
    unsigned char screen[25][40]; //25 rows, 40 columns
    unsigned char* ptr = &screen[10][13]; //row 10, column 13
    unsigned char message[] = "hello, world!";
    unsigned char row, col;
    unsigned char index = 0;

    /*
        A bit over-complicated, I know.
        But it does demonstrate both a 1D and 2D array.
        It also shows that you can index pointers just like arrays.
    */
    for (row = 0; row < 25; row++) {
        for (col = 0; col < 40; col++) {
            screen[row][col] = ' ';
        }
    }

    while (message[index] != '\0') {
        *(ptr+index) = message[index];
        index++;
    }

    prt_message(&screen[0][0]);

    return 0;
}



#include <conio.h>
#include <stdio.h>
#include "cinc64.h"

void init(void);
void play_scales(void);
void finalize(void);
void play_note(unsigned char, unsigned char);

unsigned char octave1[] = {
    1,12, 1,28, 1,45, 1,62,
    1,81, 1,102, 1,123, 1,145,
    1,169, 1,195, 1,221, 1,250
};

unsigned char octave2[] = {
    2,24, 2,56, 2,90, 2,125,
    2,163, 2,204, 2,246, 3,35,
    3,83, 3,134, 3,187, 3,244
};

unsigned char octave3[] = {
    4,48, 4,112, 4,180, 4,251,
    5,71, 5,152, 5,237, 6,71,
    6,167, 7,12, 7,119, 7,233
};

unsigned char octave4[] = {
    8,97, 8,225, 9,104, 9,247,
    10,143, 11,48, 11,218, 12,143,
    13,78, 14,24, 14,239, 15,210
};

unsigned char octave5[] = {
    16,195, 17,195, 18,209, 19,239,
    21,31, 22,96, 23,181, 25,30,
    26,156, 28,49, 29,223, 31,165
};

unsigned char octave6[] = {
    33,135, 35,134, 37,162, 39,223,
    42,62, 44,193, 47,107, 50,60,
    53,57, 56,99, 59,190, 63,75
};

unsigned char octave7[] = {
    67,15, 71,12, 75,69, 79,191,
    84,125, 89,131, 94,214, 100,121,
    106,115, 112,199, 119,123, 126,151
};

unsigned char octave8[] = {
    134,30, 142,24, 150,139, 159,126,
    168,250, 179,6, 189,172, 200,243,
    212,230, 225,143, 238,248, 253,46
};

int main(void) {
    init();
    play_scales();
    finalize();
    return 0;
}

void init(void) {
    unsigned char* s_index=0; //sid pointer index
    //Initialize SID
    for (s_index=&SID_START; s_index<=&SID_END; s_index++) {
        *s_index=0;
    }    
    clrscr();

    SID_VOLUME=15;
    //Set ASDR
    VOICE_1_AD=128;
    VOICE_1_SR=68;
    //Set pulse width for the pulse waveform.
    VOICE_1_PULSE_LOW=128;
    VOICE_1_PULSE_HIGH=247;
}

void play_scales(void) {
	unsigned char octave=0;
	unsigned char index=0;
	for (octave=1; octave<9; octave++)
	{
		printf("Octave %d\n",octave);
		for (index = 0; index < 12; index++)
		{
			switch (octave)
			{
				case 1:
					play_note(octave1[index*2], octave1[index*2+1]);
					break;
				case 2:
					play_note(octave2[index*2], octave2[index*2+1]);
					break;
				case 3:
					play_note(octave3[index*2], octave3[index*2+1]);
					break;
				case 4:
					play_note(octave4[index*2], octave4[index*2+1]);
					break;
				case 5:
					play_note(octave5[index*2], octave5[index*2+1]);
					break;
				case 6:
					play_note(octave6[index*2], octave6[index*2+1]);
					break;
				case 7:
					play_note(octave7[index*2], octave7[index*2+1]);
					break;
				case 8:
					play_note(octave8[index*2], octave8[index*2+1]);
					break;
			}
		}
	}
}

void finalize(void) {
    unsigned char* s_index=0; //sid pointer index
    //Initialize SID
    for (s_index=&SID_START; s_index<=&SID_END; s_index++) {
        *s_index=0;
    }     
}

void play_note(unsigned char high, unsigned char low) {
		VOICE_1_WAVEFORM=65; //Start pulse waveform.
		//Set Pitch
		VOICE_1_LOW_FREQ=low;
		VOICE_1_HIGH_FREQ=high;	
		WAIT (30);
		VOICE_1_WAVEFORM=64; //End pulse waveform.	
}

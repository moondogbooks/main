#include<stdio.h>


//The implentation is entered after the function is called.
//That is why we need the protoype.
int times4(int* myvar); 

int main(void) {
	int var1=24;
	printf("%d times 4 is %d\n", var1, times4(&var1));
	printf("The value of var1 changed. It is now %d.\n", var1);
    return 0;
}

int times4(int* myvar) {
    *myvar *= 4;
    return *myvar;
}

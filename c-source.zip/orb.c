#include <tgi.h>
#include "cinc64.h"

void wait(unsigned char);

static const unsigned char palette[2] = {
    TGI_COLOR_BLUE,
    TGI_COLOR_YELLOW
};

int main(void)
{
    char index = 0;

    tgi_install(tgi_static_stddrv);
    tgi_init();
    tgi_setpalette(palette);
    tgi_setcolor(1);

    tgi_clear();

    tgi_circle(160,100,80); 
    for (index = 0; index < 80; index += 10) {
        tgi_ellipse(160, 100, index, 80);
        tgi_ellipse(160, 100, 80, index);
    }

    WAIT(240);

    tgi_done();
    tgi_unload();
  
    return 1;
}



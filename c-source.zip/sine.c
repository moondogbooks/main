#include <tgi.h>
#include <cc65.h> //Needed by _sin(angle)
#include "cinc64.h"

static const unsigned char palette[2] = {
    TGI_COLOR_WHITE,
    TGI_COLOR_BLACK
};

int main(void)
{
    unsigned int x=0;
    unsigned int y=0;
    unsigned int angle=0;
    tgi_install(tgi_static_stddrv);
    tgi_init();
    tgi_setpalette(palette);
    tgi_setcolor(1);   /* draw with palette entry 1 */

    tgi_clear();

    for (x=0; x<320; x++) {
        angle = (x * 2) % 360; //Return an angle from 0 359 for x.
        y = 90 + (45 * _sin(angle)) / 256; 
        tgi_setpixel(x, y);
    }

    WAIT(180);

    tgi_done();
    tgi_unload();

    return 0;
}

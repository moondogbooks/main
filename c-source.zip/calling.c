
#include "mylib.h"

int main(void) {
	setcolor(BLACK, BLACK, LIGHTGREEN);
	hello(14,10);
    return 0;
}

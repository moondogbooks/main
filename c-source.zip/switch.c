#include<stdio.h>

int main(void) {
    unsigned char x=0;

    for (x=0; x<=11; x++) {
        switch (x) {
            case 1:
                printf("x is one\n");
                break;
            case 2:
                printf("x is two\n");
                break;
            case 3:
                printf("x is three\n");
                break;
            case 4:
                printf("x is four\n");
                break;
            case 5:
                printf("x is five\n");
                break;
            case 6:
                printf("x is six\n");
                break;
            case 7:
                printf("x is seven\n");
                break;
            case 8:
                printf("x is eight\n");
                break;
            case 9:
                printf("x is nine\n");
                break;
            case 10:
                printf("x is ten\n");
                break;
            default:
                printf("x is not between 1 and 10\n");
                break;
        }
    }
    return 0;
}

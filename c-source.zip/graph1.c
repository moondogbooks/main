#include <conio.h>
#include <c64.h>

int main(void) {
    unsigned char* screen=(unsigned char*)0x0400;
    unsigned char* color=(unsigned char*)0xD800;
    
    unsigned char save_backcolor=bgcolor(COLOR_BLACK); 
    unsigned char save_bordercolor=bordercolor(COLOR_GRAY1);

    clrscr();

    *screen = 1; //a
    *color = COLOR_WHITE;

    *(screen+39)=2; //b
    *(color+39)=COLOR_LIGHTGREEN;

    //Treating the pointer like an array.
    screen[24*40]=3; //c
    color[24*40]=COLOR_YELLOW;

    screen[24*40+39]=4; //d
    color[24*40+39]=COLOR_CYAN;

    cgetc(); //press any key...

    bgcolor(save_backcolor);
    bordercolor(save_bordercolor);
    clrscr();
    return 0;
}

#include <stdio.h>
#include <conio.h>
#include "cinc64.h"

void save_letters_to_reu(void);
void load_letters_from_reu(void);

int main(void) {
    save_letters_to_reu();
    load_letters_from_reu();
    clrscr();
    return 1;
}

void save_letters_to_reu(void) {
    unsigned int li=0; //letter index
    unsigned int si=0; //screen index;
    for (li=0; li<=255; li++) {
        for (si=1024;si<=2023;si++) {
            *(unsigned char*)si=li;
        }
        set_source(0x400);
        set_destination((unsigned long)li * 1000);
        set_copy_bytes(1000);
        REU_ACTION=REU_COPY_FROM_C64; //Copy screen ram to reu.
    }
}

void load_letters_from_reu(void) {
    unsigned int li=0; //letter index;
    for (li=0; li<=255; li++) {
    set_source(0x400);
    set_destination((unsigned long)li * 1000);
    set_copy_bytes(1000);
    REU_ACTION=REU_COPY_FROM_REU;//Copy reu to screen ram.
    WAIT(5);
    }
}



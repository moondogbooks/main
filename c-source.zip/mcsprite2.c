#include <stdio.h>
#include <conio.h>
#include <c64.h>
#include "cinc64.h"

void init(void);
void run(void);
void finalize(void);
void raster(void);
void check_collision(void);

unsigned char alien_shape[] = {
	40,0,40,
	10,0,160,
	2,0,128,
	0,170,0,
	2,170,128,
	2,235,128,
	2,105,128,
	2,235,128,
	2,170,128,
	2,150,128,
	0,170,0,
	0,170,0,
	2,170,128,
	2,170,128,
	2,170,128,
	2,40,128,
	2,40,128,
	8,130,32,
	8,130,32,
	8,130,32,
	0,0,0
};

//Multi-color sprite example
int main(void) {
    init();
    while (KEY_COUNT==0) {
        run();
    }
    finalize();
    return 0;
}

void init(void) {
    unsigned int index=0;
    unsigned char* reg=0;
    clrscr();
    printf("Press any key to exit.");
	//Initialize sprite coordinates and X overflow.
	for (reg = &SPRITE_0_X; reg <= &SPRITE_X_OVERFLOW; reg++) {
		*reg = 0;
	}
    //Set Sprite Colors
    SPRITE_MULTICOLOR_FLAG=3; //Sprites 0-1 are multi-colored sprites.
    SPRITE_MULTICOLOR_REG_0=COLOR_RED; //Multi-color register 0 = 7;
    SPRITE_MULTICOLOR_REG_1=COLOR_WHITE; //Multi-color register 1 = 0;
    SPRITE_COLOR_0=COLOR_GREEN;
    SPRITE_COLOR_1=COLOR_BLUE; //Sprite color for sprite 1;  //Red

    //Set sprite data location to 832(13*64) for sprites 0-1.
    *(unsigned char *)2040=13;
    *(unsigned char *)2041=13;
    //Load alien shape for sprites 0-1.
    for (index=0; index<=62;index++) {
        *(unsigned char*)(index+832)=alien_shape[index];
    }

    SPRITE_ENABLE=3; //Enable sprites 0-3.
    //Expand sprite 0-1 X & Y
    SPRITE_EXPAND_X=3;
    SPRITE_EXPAND_Y=3;
}

void run(void) {
    unsigned int index=0;
    ++BACKGROUND_COLOR;
    --BORDER_COLOR;
    SPRITE_X_OVERFLOW=0; //Clear X overflow.
    for (index=30; index<=255; index++) {
        if (KEY_COUNT > 0) break;
        SPRITE_0_X=index; //Sprite 0 X
        SPRITE_1_X=index; //Sprite 1 X
        SPRITE_0_Y=index; //Sprite 0 Y
        SPRITE_1_Y=280-index; //Sprite 1 Y
        raster();
        check_collision();
    }
}

void finalize(void) {
    SPRITE_ENABLE=0; //Disable sprites
    KEY_COUNT = 0;
    clrscr();
    BACKGROUND_COLOR=COLOR_BLUE;
    BORDER_COLOR=COLOR_LIGHTBLUE;
    VIC_MEM_CONTROL_REG &= VIC_UPPER; //Return to uppercase.
}

//Raster Delay
void raster(void) {
    while (RASTER_1<128) {}
    while (RASTER_1>=128) {}    
}

void check_collision(void) {
    unsigned char colflags = SPRITE_COLLISION;
    //Let's not check for collisions until sprite 1 is fully on screen.
    if (SPRITE_1_X > 229 || SPRITE_1_X < 29) return;
    if ((colflags & 3) == 3) {
        BORDER_COLOR++;
    }
}
